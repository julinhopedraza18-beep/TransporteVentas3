/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.time.LocalDate;
import java.time.LocalTime;

public class Boleto {
    private String nroBoleto;
    private Ruta ruta;
    private Vehiculo vehiculo;
    private Conductor conductor;
    private Cliente cliente;
    private LocalDate fechaViaje;
    private LocalTime horaViaje;
    private String asiento;
    private double descuento;
    private double recargo;
    private double montoTotal;
    private boolean cancelado = false;

    public String getNroBoleto() { return nroBoleto; }
    public void setNroBoleto(String nroBoleto) {
        if (nroBoleto == null || nroBoleto.trim().isEmpty())
            throw new IllegalArgumentException("El nro de boleto no puede estar vacio.");
        this.nroBoleto = nroBoleto;
    }

    public Ruta getRuta() { return ruta; }
    public void setRuta(Ruta ruta) {
        if (ruta == null) throw new IllegalArgumentException("La ruta no puede ser nula.");
        this.ruta = ruta;
    }

    public Vehiculo getVehiculo() { return vehiculo; }
    public void setVehiculo(Vehiculo vehiculo) {
        if (vehiculo == null) throw new IllegalArgumentException("El vehiculo no puede ser nulo.");
        this.vehiculo = vehiculo;
    }

    public Conductor getConductor() { return conductor; }
    public void setConductor(Conductor conductor) {
        if (conductor == null) throw new IllegalArgumentException("El conductor no puede ser nulo.");
        this.conductor = conductor;
    }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) {
        if (cliente == null) throw new IllegalArgumentException("El cliente no puede ser nulo.");
        this.cliente = cliente;
    }

    public LocalDate getFechaViaje() { return fechaViaje; }
    public void setFechaViaje(LocalDate fechaViaje) {
        if (fechaViaje == null) throw new IllegalArgumentException("La fecha de viaje no puede ser nula.");
        this.fechaViaje = fechaViaje;
    }

    public LocalTime getHoraViaje() { return horaViaje; }
    public void setHoraViaje(LocalTime horaViaje) {
        if (horaViaje == null) throw new IllegalArgumentException("La hora de viaje no puede ser nula.");
        this.horaViaje = horaViaje;
    }

    public String getAsiento() { return asiento; }
    public void setAsiento(String asiento) {
        if (asiento == null || asiento.trim().isEmpty())
            throw new IllegalArgumentException("El asiento no puede estar vacio.");
        this.asiento = asiento.trim();
    }

    public double getDescuento() { return descuento; }
    public void setDescuento(double descuento) {
        if (descuento < 0 || descuento > 100)
            throw new IllegalArgumentException("Descuento invalido (0-100).");
        this.descuento = descuento;
    }

    public double getRecargo() { return recargo; }
    public void setRecargo(double recargo) {
        if (recargo < 0) throw new IllegalArgumentException("Recargo no puede ser negativo.");
        this.recargo = recargo;
    }

    public double getMontoTotal() { return montoTotal; }

    public boolean isCancelado() { return cancelado; }
    public void setCancelado(boolean cancelado) { this.cancelado = cancelado; }

    public void calcularTotal() {
        if (ruta == null) throw new IllegalStateException("Debe asignar una ruta antes de calcular.");
        double precio = ruta.getPrecioPasajeBase();
        this.montoTotal = precio - (precio * descuento / 100) + (precio * recargo / 100);
    }

    public void ver_datos() {
        String estado = cancelado ? " [CANCELADO]" : "";
        System.out.println("Boleto NRO: " + nroBoleto +
            " FECHA VIAJE: " + fechaViaje + " HORA: " + horaViaje +
            " RUTA: " + ruta.getOrigen() + " -> " + ruta.getDestino() +
            " ASIENTO: " + asiento +
            " CLIENTE: " + cliente.getNombre() + " " + cliente.getApe_paterno() +
            " VEHICULO: " + vehiculo.getMarca() + " " + vehiculo.getModelo() +
            " PLACA: " + vehiculo.getPlaca() +
            " CONDUCTOR: " + conductor.getNombre() + " " + conductor.getApe_paterno() +
            " DESCUENTO: " + descuento + "%" +
            " RECARGO: " + recargo + "%" +
            " TOTAL: S/. " + String.format("%.2f", montoTotal) + estado);
    }
}

