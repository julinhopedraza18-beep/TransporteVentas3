    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class MenuPrincipalGUI extends JFrame {

    // ── Paleta ─────────────────────────────────────────────────────────────────
    static final Color C_PRIMARIO  = new Color(26, 54, 93);
    static final Color C_ACENTO    = new Color(218, 165, 32);
    static final Color C_FONDO     = new Color(240, 244, 248);
    static final Color C_CARD      = Color.WHITE;
    static final Color C_BORDER    = new Color(203, 213, 225);
    static final Color C_TEXTO     = new Color(30, 41, 59);
    static final Color C_GRIS      = new Color(100, 116, 139);
    static final Color C_VERDE     = new Color(22, 163, 74);
    static final Color C_ROJO      = new Color(220, 38, 38);
    static final Color C_AMARILLO  = new Color(202, 138, 4);

    // ── Controladores ──────────────────────────────────────────────────────────
    private ControladorRuta      ctrlRuta      = new ControladorRuta();
    private ControladorVehiculo  ctrlVehiculo  = new ControladorVehiculo();
    private ControladorConductor ctrlConductor = new ControladorConductor();
    private ControladorBoleto    ctrlBoleto    = new ControladorBoleto();

    private UsuarioSistema usuarioActual;

    // ── Tablas ─────────────────────────────────────────────────────────────────
    private DefaultTableModel modeloTablaRutas;
    private DefaultTableModel modeloTablaVehiculos;
    private DefaultTableModel modeloTablaConductores;
    private DefaultTableModel modeloTablaBoletos;

    // ── Etiquetas del dashboard ────────────────────────────────────────────────
    private JLabel lblTotalBoletos, lblTotalRecaudado, lblBoletosActivos, lblBoletosCancelados;
    private JLabel lblTotalRutas, lblTotalVehiculos, lblTotalConductores;

    public MenuPrincipalGUI(UsuarioSistema usuarioActual) {
        this.usuarioActual = usuarioActual;
        configurarVentana();
        construirUI();
    }

    // ── Configuracion de la ventana ────────────────────────────────────────────
    private void configurarVentana() {
        setTitle("TransporteVentas - Sistema de Ventas | " + usuarioActual.getNombre());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 700);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        getContentPane().setBackground(C_FONDO);
    }

    // ── Construccion de la UI ─────────────────────────────────────────────────
    private void construirUI() {
        setLayout(new BorderLayout());
        add(crearPanelSuperior(), BorderLayout.NORTH);
        add(crearContenidoPrincipal(), BorderLayout.CENTER);
    }

    private JPanel crearPanelSuperior() {
        JPanel header = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, C_PRIMARIO,
                        getWidth(), 0, new Color(13, 27, 62));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        header.setPreferredSize(new Dimension(0, 64));
        header.setLayout(new BorderLayout());
        header.setBorder(new EmptyBorder(0, 24, 0, 24));

        // Izquierda: logo + nombre
        JPanel izquierda = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        izquierda.setOpaque(false);
        JLabel icono = new JLabel("🚌");
        icono.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        JPanel textoEmpresa = new JPanel();
        textoEmpresa.setOpaque(false);
        textoEmpresa.setLayout(new BoxLayout(textoEmpresa, BoxLayout.Y_AXIS));
        JLabel nombreEmpresa = new JLabel("TRANSPORTES DEL NORTE");
        nombreEmpresa.setFont(new Font("Segoe UI", Font.BOLD, 15));
        nombreEmpresa.setForeground(Color.WHITE);
        JLabel subNombre = new JLabel("Sistema de Ventas");
        subNombre.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        subNombre.setForeground(C_ACENTO);
        textoEmpresa.add(nombreEmpresa);
        textoEmpresa.add(subNombre);
        izquierda.add(icono);
        izquierda.add(textoEmpresa);

        // Derecha: usuario + cerrar sesion
        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        derecha.setOpaque(false);
        String rolLabel = usuarioActual.getRol().substring(0, 1).toUpperCase() + usuarioActual.getRol().substring(1);
        JLabel lblUser = new JLabel("👤 " + usuarioActual.getNombre() + "  |  " + rolLabel);
        lblUser.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblUser.setForeground(Color.WHITE);
        JButton btnSalir = new JButton("Cerrar Sesion");
        estilizarBotonHeader(btnSalir);
        btnSalir.addActionListener(e -> cerrarSesion());
        derecha.add(lblUser);
        derecha.add(btnSalir);

        header.add(izquierda, BorderLayout.WEST);
        header.add(derecha, BorderLayout.EAST);
        return header;
    }

    private JPanel crearContenidoPrincipal() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabs.setBackground(C_FONDO);

        String rol = usuarioActual.getRol();

        // Dashboard: todos los roles
        tabs.addTab("📊 Dashboard", crearPanelDashboard());

        // Rutas: solo admin y supervisor
        if (rol.equals("admin") || rol.equals("supervisor")) {
            tabs.addTab("🗺 Rutas", crearPanelRutas());
        }

        // Vehiculos: solo admin y supervisor
        if (rol.equals("admin") || rol.equals("supervisor")) {
            tabs.addTab("🚌 Vehículos", crearPanelVehiculos());
        }

        // Conductores: solo admin y supervisor
        if (rol.equals("admin") || rol.equals("supervisor")) {
            tabs.addTab("👨 Conductores", crearPanelConductores());
        }

        // Emitir Boleto: solo admin y vendedor
        if (rol.equals("admin") || rol.equals("vendedor")) {
            tabs.addTab("🎫 Emitir Boleto", crearPanelEmitirBoleto());
        }

        // Boletos: todos los roles
        tabs.addTab("📋 Boletos", crearPanelBoletos());

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(C_FONDO);
        wrapper.setBorder(new EmptyBorder(0, 0, 0, 0));
        wrapper.add(tabs, BorderLayout.CENTER);
        return wrapper;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PANEL DASHBOARD
    // ═══════════════════════════════════════════════════════════════════════════
    private JPanel crearPanelDashboard() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(C_FONDO);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel titulo = new JLabel("Resumen General del Sistema");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(C_PRIMARIO);
        titulo.setBorder(new EmptyBorder(0, 0, 16, 0));
        panel.add(titulo, BorderLayout.NORTH);

        // Cards de estadísticas
        JPanel cards = new JPanel(new GridLayout(2, 4, 14, 14));
        cards.setBackground(C_FONDO);

        lblTotalBoletos    = new JLabel("0");
        lblTotalRecaudado  = new JLabel("S/. 0.00");
        lblBoletosActivos  = new JLabel("0");
        lblBoletosCancelados = new JLabel("0");
        lblTotalRutas      = new JLabel("0");
        lblTotalVehiculos  = new JLabel("0");
        lblTotalConductores = new JLabel("0");

        cards.add(crearCard("Total Boletos",     lblTotalBoletos,     "🎫", C_PRIMARIO));
        cards.add(crearCard("Recaudado (S/.)",   lblTotalRecaudado,   "💰", C_VERDE));
        cards.add(crearCard("Boletos Activos",   lblBoletosActivos,   "✅", C_VERDE));
        cards.add(crearCard("Cancelados",        lblBoletosCancelados,"❌", C_ROJO));
        cards.add(crearCard("Rutas Registradas", lblTotalRutas,       "🗺", C_ACENTO));
        cards.add(crearCard("Flota Vehiculos",   lblTotalVehiculos,   "🚌", C_PRIMARIO));
        cards.add(crearCard("Conductores",       lblTotalConductores, "👨", new Color(107, 33, 168)));
        cards.add(crearCard("Sistema",           new JLabel("Activo ✓"), "⚙", C_VERDE));

        panel.add(cards, BorderLayout.CENTER);

        // Boton refrescar
        JButton btnRefrescar = crearBotonPrimario("↻ Actualizar Estadisticas");
        btnRefrescar.addActionListener(e -> actualizarDashboard());
        JPanel sur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sur.setBackground(C_FONDO);
        sur.add(btnRefrescar);
        panel.add(sur, BorderLayout.SOUTH);

        actualizarDashboard();
        return panel;
    }

    private JPanel crearCard(String titulo, JLabel valor, String emoji, Color color) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(C_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(C_BORDER, 1, true),
            new EmptyBorder(16, 16, 16, 16)
        ));

        JLabel ico = new JLabel(emoji);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        ico.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel tit = new JLabel(titulo);
        tit.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tit.setForeground(C_GRIS);
        tit.setAlignmentX(Component.LEFT_ALIGNMENT);

        valor.setFont(new Font("Segoe UI", Font.BOLD, 22));
        valor.setForeground(color);
        valor.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(ico);
        card.add(Box.createVerticalStrut(8));
        card.add(tit);
        card.add(Box.createVerticalStrut(4));
        card.add(valor);
        return card;
    }

    private void actualizarDashboard() {
        lblTotalBoletos.setText(String.valueOf(ctrlBoleto.getTotalBoletos()));
        lblTotalRecaudado.setText("S/. " + String.format("%.2f", ctrlBoleto.getTotalRecaudado()));
        lblBoletosActivos.setText(String.valueOf(ctrlBoleto.getBoletosActivos()));
        lblBoletosCancelados.setText(String.valueOf(ctrlBoleto.getBoletosCancelados()));
        lblTotalRutas.setText(String.valueOf(ctrlRuta.getTotalRutas()));
        lblTotalVehiculos.setText(String.valueOf(ctrlVehiculo.getTotalVehiculos()));
        lblTotalConductores.setText(String.valueOf(ctrlConductor.getTotalConductores()));
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PANEL RUTAS
    // ═══════════════════════════════════════════════════════════════════════════
    private JPanel crearPanelRutas() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(C_FONDO);
        panel.setBorder(new EmptyBorder(16, 16, 16, 16));

        // Formulario
        JPanel formCard = crearCard("Registrar Nueva Ruta");
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        JTextField tfCodigo = nuevoTF();
        JTextField tfOrigen = nuevoTF("Trujillo");
        tfOrigen.setEditable(false);
        tfOrigen.setForeground(C_GRIS);
        tfOrigen.setBackground(new Color(240, 244, 248));
        JTextField tfDestino   = nuevoTF(); JTextField tfDistancia = nuevoTF();
        JTextField tfDuracion = nuevoTF();
        tfDuracion.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                // Solo numeros y punto decimal
                if (!Character.isDigit(c) && c != '.') { e.consume(); return; }
                // Solo un punto decimal
                if (c == '.' && tfDuracion.getText().contains(".")) e.consume();
            }
            @Override public void keyReleased(KeyEvent e) {
                try {
                    double horas = Double.parseDouble(tfDuracion.getText());
                    if (horas <= 0 || horas > 72) {
                        tfDuracion.setForeground(C_ROJO);
                        tfDuracion.setToolTipText("Ingrese horas validas entre 0.1 y 72");
                    } else {
                        tfDuracion.setForeground(C_TEXTO);
                        tfDuracion.setToolTipText("Duracion en horas. Ejemplo: 1.5 = 1 hora 30 min");
                    }
                } catch (NumberFormatException ignored) {}
            }
        });
        JTextField tfPrecio = nuevoTF();

        Object[][] camposRuta = {
            {"Codigo Ruta *", tfCodigo, "Origen *", tfOrigen},
            {"Destino *", tfDestino, "Distancia (km) *", tfDistancia},
            {"Duracion (horas) *", tfDuracion, "Precio Base (S/.) *", tfPrecio}
        };
        for (int i = 0; i < camposRuta.length; i++) {
            for (int j = 0; j < 4; j += 2) {
                g.gridx = j; g.gridy = i; g.weightx = 0;
                formCard.add(lblCampo((String) camposRuta[i][j]), g);
                g.gridx = j + 1; g.weightx = 1;
                formCard.add((JTextField) camposRuta[i][j + 1], g);
            }
        }

        JButton btnGuardar = crearBotonPrimario("+ Registrar Ruta");
        JButton btnLimpiar = crearBotonSecundario("Limpiar");
        g.gridx = 0; g.gridy = 3; g.gridwidth = 2; g.weightx = 0;
        formCard.add(btnGuardar, g);
        g.gridx = 2; g.gridwidth = 2;
        formCard.add(btnLimpiar, g);

        btnLimpiar.addActionListener(e -> {
            tfCodigo.setText(""); tfOrigen.setText(""); tfDestino.setText("");
            tfDistancia.setText(""); tfDuracion.setText(""); tfPrecio.setText("");
        });

        btnGuardar.addActionListener(e -> {
            try {
                String origen  = tfOrigen.getText().trim();
                String destino = tfDestino.getText().trim();

                if (origen.equalsIgnoreCase(destino))
                    throw new IllegalArgumentException("El origen y el destino no pueden ser el mismo lugar.");

                Ruta r = new Ruta();
                r.setCodigoRuta(tfCodigo.getText());
                r.setOrigen(origen);
                r.setDestino(destino);
                r.setDistanciaKm(parseDouble(tfDistancia.getText(), "Distancia"));
                double horas = parseDouble(tfDuracion.getText(), "Duracion");
                if (horas <= 0 || horas > 72)
                    throw new IllegalArgumentException(
                        "La duracion debe estar entre 0.1 y 72 horas.");
                r.setDuracionMinutos((int) Math.round(horas * 60));
                r.setPrecioPasajeBase(parseDouble(tfPrecio.getText(), "Precio"));
                ctrlRuta.agregar_ruta(r);
                refrescarTablaRutas();
                actualizarDashboard();
                btnLimpiar.doClick();
                mostrarExito("Ruta registrada correctamente.");
            } catch (Exception ex) {
                mostrarError("Error: " + ex.getMessage());
            }
        });

        // Tabla de rutas
        String[] colsRuta = {"Codigo", "Origen", "Destino", "Distancia (km)",
                             "Duracion", "Precio Base", "Clasificacion", "Estado"};
        modeloTablaRutas = new DefaultTableModel(colsRuta, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tablaRutas = crearTabla(modeloTablaRutas);

        JButton btnEliminar = crearBotonRojo("🗑 Eliminar Ruta");
        JButton btnToggle   = crearBotonSecundario("Activar / Desactivar");
        btnEliminar.addActionListener(e -> {
            int fila = tablaRutas.getSelectedRow();
            if (fila < 0) { mostrarError("Seleccione una ruta."); return; }
            String cod = (String) modeloTablaRutas.getValueAt(fila, 0);
            if (confirmar("¿Eliminar la ruta " + cod + "?")) {
                ctrlRuta.eliminarPorCodigo(cod);
                refrescarTablaRutas();
                actualizarDashboard();
            }
        });
        btnToggle.addActionListener(e -> {
            int fila = tablaRutas.getSelectedRow();
            if (fila < 0) { mostrarError("Seleccione una ruta."); return; }
            String cod = (String) modeloTablaRutas.getValueAt(fila, 0);
            Ruta r = ctrlRuta.buscarPorCodigo(cod);
            if (r != null) {
                boolean nuevoEstado = !r.isActiva();
                ctrlRuta.actualizarEstado(cod, nuevoEstado);
                refrescarTablaRutas();
                mostrarExito("Ruta " + cod + (nuevoEstado ? " activada." : " desactivada."));
            }
        });

        JPanel botonesTabla = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        botonesTabla.setBackground(C_FONDO);
        botonesTabla.add(btnToggle);
        botonesTabla.add(btnEliminar);

        panel.add(formCard, BorderLayout.NORTH);
        panel.add(new JScrollPane(tablaRutas), BorderLayout.CENTER);
        panel.add(botonesTabla, BorderLayout.SOUTH);

        refrescarTablaRutas();
        return panel;
    }

    private void refrescarTablaRutas() {
        modeloTablaRutas.setRowCount(0);
        for (int i = 0; i < ctrlRuta.rutas.size(); i++) {
            Ruta r = ctrlRuta.rutas.get(i);
            modeloTablaRutas.addRow(new Object[]{
                r.getCodigoRuta(), r.getOrigen(), r.getDestino(),
                r.getDistanciaKm(), r.getDuracionFormateada(),
                "S/. " + String.format("%.2f", r.getPrecioPasajeBase()),
                r.clasificarRuta(), r.isActiva() ? "Activa" : "Inactiva"
            });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PANEL VEHICULOS
    // ═══════════════════════════════════════════════════════════════════════════
    private JPanel crearPanelVehiculos() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(C_FONDO);
        panel.setBorder(new EmptyBorder(16, 16, 16, 16));

        JPanel formCard = crearCard("Registrar Nuevo Vehiculo");
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        JComboBox<String> cmbTipo = new JComboBox<>(new String[]{"Bus", "Combi"});
        JTextField tfPlaca = nuevoTF();
        JComboBox<String> cmbMarca = new JComboBox<>(new String[]{
            "Mercedes-Benz", "Volvo", "Scania", "Hino", "Yutong",
            "Toyota", "Nissan", "Hyundai", "Volkswagen", "MAN",
            "Iveco", "Daewoo", "Kia", "Mitsubishi", "Isuzu",
            "Zhongtong", "King Long", "Golden Dragon", "Ankai",
            "Ford", "Chevrolet", "JAC", "Dongfeng", "Foton",
            "Marcopolo", "Irizar", "Comil", "Busscar"
        });

        // Modelos filtrados segun la marca seleccionada
        JComboBox<String> cmbModelo = new JComboBox<>();

        // Mapa de marcas con sus modelos reales
        java.util.Map<String, String[]> modelosPorMarca = new java.util.LinkedHashMap<>();
        modelosPorMarca.put("Mercedes-Benz", new String[]{"OF-1721","OF-1418","O-500R","O-500RS","Sprinter"});
        modelosPorMarca.put("Volvo",         new String[]{"B9R","B12B","B12M","B270F","B380R"});
        modelosPorMarca.put("Scania",        new String[]{"K360","K410","K124IB","F94HB","K94IB"});
        modelosPorMarca.put("Hino",          new String[]{"AK1J","AK8J","RK1J","RK8J","SG1J"});
        modelosPorMarca.put("Yutong",        new String[]{"ZK6122H","ZK6119H","ZK6109H","ZK6906H","ZK6100H"});
        modelosPorMarca.put("Toyota",        new String[]{"Hiace","Coaster","Land Cruiser"});
        modelosPorMarca.put("Nissan",        new String[]{"Urvan","Civilian","Caravan"});
        modelosPorMarca.put("Hyundai",       new String[]{"H-1","County","Universe","Aero City"});
        modelosPorMarca.put("Volkswagen",    new String[]{"Crafter","17-210","17-230","9-150OD"});
        modelosPorMarca.put("MAN",           new String[]{"18-280","18-310","24-280","Lions Coach"});
        modelosPorMarca.put("Iveco",         new String[]{"Daily","Cursor","Tector","Vertis"});
        modelosPorMarca.put("Daewoo",        new String[]{"BH120","BH115","BS106","BH090"});
        modelosPorMarca.put("Kia",           new String[]{"Granbird","Cosmos","Besta"});
        modelosPorMarca.put("Mitsubishi",    new String[]{"Rosa","Fuso","Canter"});
        modelosPorMarca.put("Isuzu",         new String[]{"LT134","NQR","NKR","FRR"});
        modelosPorMarca.put("Zhongtong",     new String[]{"LCK6120","LCK6125","LCK6147"});
        modelosPorMarca.put("King Long",     new String[]{"XMQ6127","XMQ6900","XMQ6119"});
        modelosPorMarca.put("Golden Dragon", new String[]{"XML6125","XML6113","XML6900"});
        modelosPorMarca.put("Ankai",         new String[]{"HFF6120","HFF6900","HFF6110"});
        modelosPorMarca.put("Ford",          new String[]{"Transit","F-350","F-4000"});
        modelosPorMarca.put("Chevrolet",     new String[]{"NHR","NPR","NQR"});
        modelosPorMarca.put("JAC",           new String[]{"HFC6700","HFC6120","HFC6900"});
        modelosPorMarca.put("Dongfeng",      new String[]{"EQ6120","EQ6900","EQ6110"});
        modelosPorMarca.put("Foton",         new String[]{"BJ6120","BJ6900","BJ6110"});
        modelosPorMarca.put("Marcopolo",     new String[]{"Paradiso 1800","Viaggio 1050","Audace 1150"});
        modelosPorMarca.put("Irizar",        new String[]{"i6","i8","Century","PB"});
        modelosPorMarca.put("Comil",         new String[]{"Campione 3.45","Invictus 1200","Versatile"});
        modelosPorMarca.put("Busscar",       new String[]{"Vissta Buss LO","El Buss 340","Jum Buss 400"});

        // Cargar modelos al cambiar marca
        cmbMarca.addActionListener(e -> {
            String marcaSel = (String) cmbMarca.getSelectedItem();
            cmbModelo.removeAllItems();
            String[] modelos = modelosPorMarca.get(marcaSel);
            if (modelos != null) {
                for (String mod : modelos) cmbModelo.addItem(mod);
            }
        });
        // Cargar modelos iniciales
        String[] modelosIniciales = modelosPorMarca.get(cmbMarca.getSelectedItem());
        if (modelosIniciales != null) {
            for (String mod : modelosIniciales) cmbModelo.addItem(mod);
        }

        JTextField tfAnio = nuevoTF();
        // Solo numeros, maximo 4 digitos, maximo 2026
        tfAnio.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) { e.consume(); return; }
                if (tfAnio.getText().length() >= 4) e.consume();
            }
            @Override public void keyReleased(KeyEvent e) {
                try {
                    int a = Integer.parseInt(tfAnio.getText());
                    if (a > 2026) tfAnio.setForeground(C_ROJO);
                    else          tfAnio.setForeground(C_TEXTO);
                } catch (NumberFormatException ignored) {}
            }
        });

        JTextField tfCapacidad = nuevoTF();
        // Solo numeros, maximo 3 digitos
        tfCapacidad.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) { e.consume(); return; }
                if (tfCapacidad.getText().length() >= 3) e.consume();
            }
        });
        JComboBox<String> cmbTipoBus  = new JComboBox<>(new String[]{"interprovincial","urbano","turistico"});
        JComboBox<String> cmbTipoRuta = new JComboBox<>(new String[]{"urbana","interdistrital","rural"});
        JCheckBox chkAire   = new JCheckBox("Aire Acondicionado");
        JCheckBox chkMusica = new JCheckBox("Con Musica");
        JTextField tfPisos  = nuevoTF("1");
        chkAire.setBackground(C_CARD);
        chkMusica.setBackground(C_CARD);

        // Si es Combi: bloquear pisos en 1 y capacidad maxima 20
        // Si es Bus: permitir 1 o 2 pisos
        cmbTipo.addActionListener(e -> {
            String tipo = (String) cmbTipo.getSelectedItem();
            if ("Combi".equals(tipo)) {
                tfPisos.setText("1");
                tfPisos.setEditable(false);
                tfPisos.setForeground(C_GRIS);
                tfPisos.setToolTipText("Las combis solo tienen 1 piso");
            } else {
                tfPisos.setEditable(true);
                tfPisos.setForeground(C_TEXTO);
                tfPisos.setToolTipText("Ingrese 1 o 2 pisos");
            }
        });

        // Solo numeros en pisos, maximo 1 digito, valor 1 o 2
        tfPisos.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) { e.consume(); return; }
                tfPisos.setText("");
            }
            @Override public void keyReleased(KeyEvent e) {
                try {
                    int p = Integer.parseInt(tfPisos.getText());
                    if (p < 1 || p > 2) {
                        tfPisos.setForeground(C_ROJO);
                        tfPisos.setToolTipText("Solo se permite 1 o 2 pisos");
                    } else {
                        tfPisos.setForeground(C_TEXTO);
                    }
                } catch (NumberFormatException ignored) {}
            }
        });

        // Fila 0
        g.gridx=0;g.gridy=0;g.weightx=0; formCard.add(lblCampo("Tipo *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbTipo,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Placa *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfPlaca,g);
        // Fila 1
        g.gridx=0;g.gridy=1;g.weightx=0; formCard.add(lblCampo("Marca *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbMarca,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Modelo *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(cmbModelo,g);
        // Fila 2
        g.gridx=0;g.gridy=2;g.weightx=0; formCard.add(lblCampo("Anio *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(tfAnio,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Capacidad *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfCapacidad,g);
        // Fila 3 - especificos Bus
        g.gridx=0;g.gridy=3;g.weightx=0; formCard.add(lblCampo("Tipo Bus"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbTipoBus,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("N° Pisos"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfPisos,g);
        // Fila 4 - especificos Combi
        g.gridx=0;g.gridy=4;g.weightx=0; formCard.add(lblCampo("Tipo Ruta"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbTipoRuta,g);
        g.gridx=2;g.weightx=0;            formCard.add(chkAire,g);
        g.gridx=3;g.weightx=1;            formCard.add(chkMusica,g);

        JButton btnGuardar = crearBotonPrimario("+ Registrar Vehiculo");
        JButton btnLimpiar = crearBotonSecundario("Limpiar");
        g.gridx=0;g.gridy=5;g.gridwidth=2;g.weightx=0; formCard.add(btnGuardar,g);
        g.gridx=2;g.gridwidth=2;                        formCard.add(btnLimpiar,g);

        btnGuardar.addActionListener(e -> {
            try {
                String tipo = (String) cmbTipo.getSelectedItem();
                Vehiculo v;
                if ("Bus".equals(tipo)) {
                    Bus b = new Bus();
                    b.setTipoBus((String) cmbTipoBus.getSelectedItem());
                    b.setTieneAireAcondicionado(chkAire.isSelected());
                    b.setNumeroPisos((int) parseDouble(tfPisos.getText(), "Pisos"));
                    v = b;
                } else {
                    Conbi c = new Conbi();
                    c.setTipoRuta((String) cmbTipoRuta.getSelectedItem());
                    c.setTieneMusica(chkMusica.isSelected());
                    v = c;
                }
                v.setPlaca(tfPlaca.getText());
                v.setMarca((String) cmbMarca.getSelectedItem());
                v.setModelo((String) cmbModelo.getSelectedItem());
                v.setAnio((int) parseDouble(tfAnio.getText(), "Anio"));
                v.setCapacidadPasajeros((int) parseDouble(tfCapacidad.getText(), "Capacidad"));
                v.validarCapacidad();
                ctrlVehiculo.agregar_vehiculo(v);
                refrescarTablaVehiculos();
                actualizarDashboard();
                btnLimpiar.doClick();
                mostrarExito("Vehiculo registrado correctamente.");
            } catch (Exception ex) {
                mostrarError("Error: " + ex.getMessage());
            }
        });
        btnLimpiar.addActionListener(e -> {
            tfPlaca.setText("");
            cmbMarca.setSelectedIndex(0);
            tfAnio.setText(""); tfCapacidad.setText(""); tfPisos.setText("1");
            chkAire.setSelected(false); chkMusica.setSelected(false);
        });

        String[] colsV = {"Placa","Tipo","Marca","Modelo","Año","Capacidad","Categoria","Operativo"};
        modeloTablaVehiculos = new DefaultTableModel(colsV, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tablaV = crearTabla(modeloTablaVehiculos);

        JButton btnElim   = crearBotonRojo("🗑 Eliminar");
        JButton btnToggle = crearBotonSecundario("Operativo / Fuera de Servicio");
        btnElim.addActionListener(e -> {
            int f = tablaV.getSelectedRow(); if(f<0){mostrarError("Seleccione un vehiculo.");return;}
            String placa = (String) modeloTablaVehiculos.getValueAt(f,0);
            if(confirmar("¿Eliminar vehiculo " + placa + "?")){
                ctrlVehiculo.eliminarPorPlaca(placa); refrescarTablaVehiculos(); actualizarDashboard();
            }
        });
        btnToggle.addActionListener(e -> {
            int f = tablaV.getSelectedRow();
            if(f<0){mostrarError("Seleccione un vehiculo.");return;}
            String placa = (String) modeloTablaVehiculos.getValueAt(f,0);
            Vehiculo v = ctrlVehiculo.buscarPorPlaca(placa);
            if(v!=null){
                boolean nuevoEstado = !v.isOperativo();
                ctrlVehiculo.actualizarEstado(placa, nuevoEstado);
                refrescarTablaVehiculos();
                mostrarExito("Vehiculo " + placa + (nuevoEstado ? " operativo." : " fuera de servicio."));
            }
        });

        JPanel bots = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        bots.setBackground(C_FONDO);
        bots.add(btnToggle); bots.add(btnElim);

        panel.add(formCard, BorderLayout.NORTH);
        panel.add(new JScrollPane(tablaV), BorderLayout.CENTER);
        panel.add(bots, BorderLayout.SOUTH);

        refrescarTablaVehiculos();
        return panel;
    }

    private void refrescarTablaVehiculos() {
        modeloTablaVehiculos.setRowCount(0);
        for (int i = 0; i < ctrlVehiculo.flota.size(); i++) {
            Vehiculo v = ctrlVehiculo.flota.get(i);
            String tipo = (v instanceof Bus) ? "Bus" : "Combi";
            modeloTablaVehiculos.addRow(new Object[]{
                v.getPlaca(), tipo, v.getMarca(), v.getModelo(), v.getAnio(),
                v.getCapacidadPasajeros(), v.determinarCategoria(),
                v.isOperativo() ? "Operativo" : "Fuera de Servicio"
            });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PANEL CONDUCTORES
    // ═══════════════════════════════════════════════════════════════════════════
    private JPanel crearPanelConductores() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(C_FONDO);
        panel.setBorder(new EmptyBorder(16, 16, 16, 16));

        JPanel formCard = crearCard("Registrar Conductor");
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        JComboBox<String> cmbTipoDoc = new JComboBox<>(new String[]{"DNI","CE","PASAPORTE"});

        // Campo NroDocumento con validacion por tipo
        JTextField tfNroDoc = nuevoTF();
        tfNroDoc.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                String tipo = (String) cmbTipoDoc.getSelectedItem();
                char c = e.getKeyChar();
                if ("DNI".equals(tipo)) {
                    if (!Character.isDigit(c)) { e.consume(); return; }
                    if (tfNroDoc.getText().length() >= 8) e.consume();
                } else if ("CE".equals(tipo)) {
                    if (tfNroDoc.getText().length() >= 12) e.consume();
                }
            }
        });
        cmbTipoDoc.addActionListener(e -> tfNroDoc.setText(""));

        // Campos de solo letras
        JTextField tfNombre = nuevoTF();
        tfNombre.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' '
                    && c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú'
                    && c != 'Á' && c != 'É' && c != 'Í' && c != 'Ó' && c != 'Ú'
                    && c != 'ñ' && c != 'Ñ') {
                    e.consume();
                }
            }
        });

        JTextField tfPaterno = nuevoTF();
        tfPaterno.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' '
                    && c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú'
                    && c != 'Á' && c != 'É' && c != 'Í' && c != 'Ó' && c != 'Ú'
                    && c != 'ñ' && c != 'Ñ') {
                    e.consume();
                }
            }
        });

        JTextField tfMaterno = nuevoTF();
        tfMaterno.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' '
                    && c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú'
                    && c != 'Á' && c != 'É' && c != 'Í' && c != 'Ó' && c != 'Ú'
                    && c != 'ñ' && c != 'Ñ') {
                    e.consume();
                }
            }
        });

        // Telefono: solo numeros, 9 digitos, empieza con 9
        JTextField tfTelefono = nuevoTF();
        tfTelefono.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) { e.consume(); return; }
                if (tfTelefono.getText().length() >= 9) { e.consume(); return; }
                // Primer digito obligatoriamente 9
                if (tfTelefono.getText().isEmpty() && c != '9') {
                    e.consume();
                    JOptionPane.showMessageDialog(null,
                        "El telefono debe comenzar con 9.",
                        "Validacion", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        JTextField tfLicencia = nuevoTF();

        // Validacion en tiempo real segun tipo de documento
        tfNroDoc.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                String tipo = (String) cmbTipoDoc.getSelectedItem();
                char c = e.getKeyChar();
                if ("DNI".equals(tipo)) {
                    // Solo numeros y maximo 8 digitos
                    if (!Character.isDigit(c)) {
                        e.consume();
                        return;
                    }
                    if (tfNroDoc.getText().length() >= 8) {
                        e.consume();
                    }
                } else if ("CE".equals(tipo)) {
                    // Maximo 12 caracteres alfanumericos
                    if (tfNroDoc.getText().length() >= 12) {
                        e.consume();
                    }
                }
            }
        });

        // Al cambiar tipo de documento, limpiar el campo y ajustar restriccion
        cmbTipoDoc.addActionListener(e -> tfNroDoc.setText(""));

        JComboBox<String> cmbCategoria = new JComboBox<>(
            new String[]{"A-IIa","A-IIb","A-IIIa","A-IIIb","A-IIIc"});

        g.gridx=0;g.gridy=0;g.weightx=0; formCard.add(lblCampo("Tipo Doc *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbTipoDoc,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Nro Documento *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfNroDoc,g);

        g.gridx=0;g.gridy=1;g.weightx=0; formCard.add(lblCampo("Nombres *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(tfNombre,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Ap. Paterno *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfPaterno,g);

        g.gridx=0;g.gridy=2;g.weightx=0; formCard.add(lblCampo("Ap. Materno"),g);
        g.gridx=1;g.weightx=1;            formCard.add(tfMaterno,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Telefono"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfTelefono,g);

        g.gridx=0;g.gridy=3;g.weightx=0; formCard.add(lblCampo("Nro Licencia *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(tfLicencia,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Categoria *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(cmbCategoria,g);

        JButton btnGuardar = crearBotonPrimario("+ Registrar Conductor");
        JButton btnLimpiar = crearBotonSecundario("Limpiar");
        g.gridx=0;g.gridy=4;g.gridwidth=2;g.weightx=0; formCard.add(btnGuardar,g);
        g.gridx=2;g.gridwidth=2;                        formCard.add(btnLimpiar,g);

        btnGuardar.addActionListener(e -> {
            try {
                Conductor c = new Conductor();
                c.setTipoDocumento((String) cmbTipoDoc.getSelectedItem());
                c.setNroDocumento(tfNroDoc.getText());
                c.setNombre(tfNombre.getText());
                c.setApe_paterno(tfPaterno.getText());
                c.setApe_materno(tfMaterno.getText());
                c.setTelefono(tfTelefono.getText());
                c.setNroLicencia(tfLicencia.getText());
                c.setCategoriaLicencia((String) cmbCategoria.getSelectedItem());
                ctrlConductor.agregar_conductor(c);
                refrescarTablaConductores();
                actualizarDashboard();
                btnLimpiar.doClick();
                mostrarExito("Conductor registrado correctamente.");
            } catch (Exception ex) {
                mostrarError("Error: " + ex.getMessage());
            }
        });
        btnLimpiar.addActionListener(e -> {
            tfNroDoc.setText(""); tfNombre.setText(""); tfPaterno.setText("");
            tfMaterno.setText(""); tfTelefono.setText(""); tfLicencia.setText("");
        });

        String[] colsC = {"Licencia","Nombre Completo","Doc","N° Documento","Telefono","Categoria","Estado"};
        modeloTablaConductores = new DefaultTableModel(colsC, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tablaC = crearTabla(modeloTablaConductores);

        JButton btnElim   = crearBotonRojo("🗑 Eliminar");
        JButton btnToggle = crearBotonSecundario("Disponible / No Disponible");
        btnElim.addActionListener(e -> {
            int f = tablaC.getSelectedRow(); if(f<0){mostrarError("Seleccione un conductor.");return;}
            String lic = (String) modeloTablaConductores.getValueAt(f,0);
            if(confirmar("¿Eliminar conductor con licencia " + lic + "?")){
                ctrlConductor.eliminarPorLicencia(lic); refrescarTablaConductores(); actualizarDashboard();
            }
        });
        btnToggle.addActionListener(e -> {
            int f = tablaC.getSelectedRow();
            if(f<0){mostrarError("Seleccione un conductor.");return;}
            String lic = (String) modeloTablaConductores.getValueAt(f,0);
            Conductor c = ctrlConductor.buscarPorLicencia(lic);
            if(c!=null){
                boolean nuevoEstado = !c.isDisponible();
                ctrlConductor.actualizarDisponibilidad(lic, nuevoEstado);
                refrescarTablaConductores();
                mostrarExito("Conductor " + lic + (nuevoEstado ? " disponible." : " no disponible."));
            }
        });

        JPanel bots = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        bots.setBackground(C_FONDO); bots.add(btnToggle); bots.add(btnElim);

        panel.add(formCard, BorderLayout.NORTH);
        panel.add(new JScrollPane(tablaC), BorderLayout.CENTER);
        panel.add(bots, BorderLayout.SOUTH);

        refrescarTablaConductores();
        return panel;
    }

    private void refrescarTablaConductores() {
        modeloTablaConductores.setRowCount(0);
        for (int i = 0; i < ctrlConductor.conductores.size(); i++) {
            Conductor c = ctrlConductor.conductores.get(i);
            modeloTablaConductores.addRow(new Object[]{
                c.getNroLicencia(), c.getNombreCompleto(),
                c.getTipoDocumento(), c.getNroDocumento(),
                c.getTelefono(), c.getCategoriaLicencia(),
                c.isDisponible() ? "Disponible" : "No Disponible"
            });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PANEL EMITIR BOLETO
    // ═══════════════════════════════════════════════════════════════════════════
    private JPanel crearPanelEmitirBoleto() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(C_FONDO);
        panel.setBorder(new EmptyBorder(16, 16, 16, 16));

        JPanel formCard = crearCard("Emision de Boleto de Pasaje");
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 6, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        
        // Campos del viaje - combos desplegables
        JComboBox<String> cmbRuta = new JComboBox<>();
        cmbRuta.addItem("-- Seleccione una ruta --");
        for (int i = 0; i < ctrlRuta.rutas.size(); i++) {
            Ruta r = ctrlRuta.rutas.get(i);
            if (r.isActiva()) {
                cmbRuta.addItem(r.getCodigoRuta() + " | " + r.getOrigen() + " → " + r.getDestino() +
                    " | S/. " + String.format("%.2f", r.getPrecioPasajeBase()));
            }
        }

        JComboBox<String> cmbPlaca = new JComboBox<>();
        cmbPlaca.addItem("-- Seleccione un vehiculo --");
        for (int i = 0; i < ctrlVehiculo.flota.size(); i++) {
            Vehiculo v = ctrlVehiculo.flota.get(i);
            if (v.isOperativo()) {
                String tipo = (v instanceof Bus) ? "Bus" : "Combi";
                cmbPlaca.addItem(v.getPlaca() + " | " + tipo + " " + v.getMarca() + " " +
                    v.getModelo() + " | Cap: " + v.getCapacidadPasajeros() + " pasajeros");
            }
        }

        JComboBox<String> cmbLicencia = new JComboBox<>();
        cmbLicencia.addItem("-- Seleccione un conductor --");
        for (int i = 0; i < ctrlConductor.conductores.size(); i++) {
            Conductor c = ctrlConductor.conductores.get(i);
            if (c.isDisponible()) {
                cmbLicencia.addItem(c.getNroLicencia() + " | " + c.getNombreCompleto() +
                    " | Cat: " + c.getCategoriaLicencia());
            }
        }

        JTextField tfFecha = nuevoTF(LocalDate.now().toString());
        JTextField tfHora      = nuevoTF(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
        JTextField tfAsiento = nuevoTF();

        // Validar asiento contra capacidad del vehiculo al perder el foco
        tfAsiento.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                String selPlaca = (String) cmbPlaca.getSelectedItem();
                if (selPlaca == null || selPlaca.startsWith("--")) return;
                String placaTexto = selPlaca.split(" \\| ")[0].trim();
                String asientoTexto = tfAsiento.getText().trim();
                if (placaTexto.isEmpty() || asientoTexto.isEmpty()) return;
                try {
                    int nroAsiento = Integer.parseInt(asientoTexto);
                    Vehiculo v = ctrlVehiculo.buscarPorPlaca(placaTexto);
                    if (v == null) return;
                    if (nroAsiento < 1 || nroAsiento > v.getCapacidadPasajeros()) {
                        mostrarError("Asiento invalido. El vehiculo " + placaTexto +
                            " tiene " + v.getCapacidadPasajeros() +
                            " asientos. Ingrese un numero entre 1 y " +
                            v.getCapacidadPasajeros() + ".");
                        tfAsiento.setText("");
                        tfAsiento.requestFocus();
                    }
                } catch (NumberFormatException ex) {
                    mostrarError("El numero de asiento debe ser un valor numerico.");
                    tfAsiento.setText("");
                    tfAsiento.requestFocus();
                }
            }
        });

        // Solo numeros en el campo asiento
        tfAsiento.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                if (!Character.isDigit(e.getKeyChar())) e.consume();
            }
        });
        
        // Campos del cliente
        JComboBox<String> cmbTipoDoc = new JComboBox<>(new String[]{"DNI","CE","PASAPORTE"});

        // NroDocumento con validacion por tipo
        JTextField tfNroDoc = nuevoTF();
        tfNroDoc.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                String tipo = (String) cmbTipoDoc.getSelectedItem();
                char c = e.getKeyChar();
                if ("DNI".equals(tipo)) {
                    if (!Character.isDigit(c)) { e.consume(); return; }
                    if (tfNroDoc.getText().length() >= 8) e.consume();
                } else if ("CE".equals(tipo)) {
                    if (tfNroDoc.getText().length() >= 12) e.consume();
                }
            }
        });
        cmbTipoDoc.addActionListener(e -> tfNroDoc.setText(""));

        // Nombres: solo letras
        JTextField tfNombre = nuevoTF();
        tfNombre.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' '
                    && c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú'
                    && c != 'Á' && c != 'É' && c != 'Í' && c != 'Ó' && c != 'Ú'
                    && c != 'ñ' && c != 'Ñ') {
                    e.consume();
                }
            }
        });

        // Apellido Paterno: solo letras
        JTextField tfPaterno = nuevoTF();
        tfPaterno.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' '
                    && c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú'
                    && c != 'Á' && c != 'É' && c != 'Í' && c != 'Ó' && c != 'Ú'
                    && c != 'ñ' && c != 'Ñ') {
                    e.consume();
                }
            }
        });

        // Apellido Materno: solo letras
        JTextField tfMaterno = nuevoTF();
        tfMaterno.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && c != ' '
                    && c != 'á' && c != 'é' && c != 'í' && c != 'ó' && c != 'ú'
                    && c != 'Á' && c != 'É' && c != 'Í' && c != 'Ó' && c != 'Ú'
                    && c != 'ñ' && c != 'Ñ') {
                    e.consume();
                }
            }
        });

        // Telefono: solo numeros, exactamente 9 digitos, empieza con 9
        JTextField tfTelefono = nuevoTF();
        tfTelefono.addKeyListener(new KeyAdapter() {
            @Override public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) { e.consume(); return; }
                if (tfTelefono.getText().length() >= 9) { e.consume(); return; }
                if (tfTelefono.getText().isEmpty() && c != '9') {
                    e.consume();
                    JOptionPane.showMessageDialog(null,
                        "El telefono debe comenzar con 9.",
                        "Validacion", JOptionPane.WARNING_MESSAGE);
                }
            }
            public void focusLost(java.awt.event.FocusEvent e) {}
        });

        // Validar al perder el foco que tenga exactamente 9 digitos
        tfTelefono.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                String tel = tfTelefono.getText().trim();
                if (!tel.isEmpty() && tel.length() != 9) {
                    mostrarError("El telefono debe tener exactamente 9 digitos.");
                    tfTelefono.setForeground(C_ROJO);
                    tfTelefono.requestFocus();
                } else {
                    tfTelefono.setForeground(C_TEXTO);
                }
            }
        });
        
        JComboBox<String> cmbTipoCliente = new JComboBox<>(new String[]{"regular","frecuente","corporativo"});
        JTextField tfDescAdicional = nuevoTF("0"); JTextField tfRecargo = nuevoTF("0");

        // Etiqueta de informacion
        JLabel lblInfo = new JLabel(" ");
        lblInfo.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblInfo.setForeground(C_GRIS);

        // Titulo secciones
        JLabel titViaje   = new JLabel("── Datos del Viaje ──────────────────────────────────");
        titViaje.setFont(new Font("Segoe UI", Font.BOLD, 12)); titViaje.setForeground(C_PRIMARIO);
        JLabel titCliente = new JLabel("── Datos del Cliente ───────────────────────────────");
        titCliente.setFont(new Font("Segoe UI", Font.BOLD, 12)); titCliente.setForeground(C_PRIMARIO);

        g.gridx=0;g.gridy=0;g.gridwidth=4;g.weightx=1; formCard.add(titViaje,g); g.gridwidth=1;

        g.gridy=1;g.gridx=0;g.weightx=0; formCard.add(lblCampo("Ruta *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbRuta,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Vehiculo *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(cmbPlaca,g);

        g.gridy=2;g.gridx=0;g.weightx=0; formCard.add(lblCampo("Conductor *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbLicencia,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Asiento *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfAsiento,g);

        g.gridy=3;g.gridx=0;g.weightx=0; formCard.add(lblCampo("Fecha Viaje *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(tfFecha,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Hora Viaje (HH:mm) *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfHora,g);

        g.gridy=4;g.gridx=0;g.gridwidth=4;g.weightx=1; formCard.add(titCliente,g); g.gridwidth=1;

        g.gridy=5;g.gridx=0;g.weightx=0; formCard.add(lblCampo("Tipo Doc *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbTipoDoc,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Nro Documento *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfNroDoc,g);

        g.gridy=6;g.gridx=0;g.weightx=0; formCard.add(lblCampo("Nombres *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(tfNombre,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Ap. Paterno *"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfPaterno,g);

        g.gridy=7;g.gridx=0;g.weightx=0; formCard.add(lblCampo("Ap. Materno"),g);
        g.gridx=1;g.weightx=1;            formCard.add(tfMaterno,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Telefono"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfTelefono,g);

        g.gridy=8;g.gridx=0;g.weightx=0; formCard.add(lblCampo("Tipo Cliente *"),g);
        g.gridx=1;g.weightx=1;            formCard.add(cmbTipoCliente,g);
        g.gridx=2;g.weightx=0;            formCard.add(lblCampo("Desc. Adicional (%)"),g);
        g.gridx=3;g.weightx=1;            formCard.add(tfDescAdicional,g);

        g.gridy=9;g.gridx=0;g.weightx=0; formCard.add(lblCampo("Recargo (%)"),g);
        g.gridx=1;g.weightx=1;            formCard.add(tfRecargo,g);
        g.gridx=2;g.gridwidth=2;          formCard.add(lblInfo,g); g.gridwidth=1;

        // Actualizar info al cambiar tipo cliente
        cmbRuta.addActionListener(e -> {
            String selR = (String) cmbRuta.getSelectedItem();
            String tipo = (String) cmbTipoCliente.getSelectedItem();
            if (selR == null || selR.startsWith("--")) return;
            String codR = selR.split(" \\| ")[0].trim();
            Ruta r = ctrlRuta.buscarPorCodigo(codR);
            if (r != null && tipo != null) {
                double dscAuto = tipo.equals("frecuente") ? 10 : tipo.equals("corporativo") ? 15 : 0;
                double precio = r.getPrecioPasajeBase();
                double total = precio - (precio * dscAuto / 100);
                lblInfo.setText("Precio base: S/." + String.format("%.2f", precio) +
                    " | Desc. auto: " + dscAuto + "% | Est. total: S/." + String.format("%.2f", total));
            }
        });

        cmbTipoCliente.addActionListener(e -> {
            String selR = (String) cmbRuta.getSelectedItem();
            String tipo = (String) cmbTipoCliente.getSelectedItem();
            if (selR == null || selR.startsWith("--")) return;
            String codR = selR.split(" \\| ")[0].trim();
            Ruta r = ctrlRuta.buscarPorCodigo(codR);
            if (r != null) {
                double dscAuto = tipo.equals("frecuente") ? 10 : tipo.equals("corporativo") ? 15 : 0;
                double dscAdicional = 0;
                try { dscAdicional = Double.parseDouble(tfDescAdicional.getText()); } catch(Exception ignored) {}
                double precio = r.getPrecioPasajeBase();
                double total  = precio - (precio * (dscAuto + dscAdicional) / 100);
                lblInfo.setText("Precio base: S/." + String.format("%.2f", precio) +
                    " | Desc. auto: " + dscAuto + "% | Est. total: S/." + String.format("%.2f", total));
            }
        });

        JButton btnEmitir  = crearBotonPrimario("🎫 Emitir Boleto");
        JButton btnLimpiar = crearBotonSecundario("Limpiar");
        g.gridy=10;g.gridx=0;g.gridwidth=2;g.weightx=0; formCard.add(btnEmitir,g);
        g.gridx=2;g.gridwidth=2;                         formCard.add(btnLimpiar,g);

        btnEmitir.addActionListener(e -> {
            try {
                // Obtener codigo de ruta del combo
                String selRuta = (String) cmbRuta.getSelectedItem();
                if (selRuta == null || selRuta.startsWith("--"))
                    throw new Exception("Seleccione una ruta de la lista.");
                String codigoRuta = selRuta.split(" \\| ")[0].trim();
                Ruta ruta = ctrlRuta.buscarPorCodigo(codigoRuta);
                if (ruta == null)     throw new Exception("Ruta no encontrada.");
                if (!ruta.isActiva()) throw new Exception("La ruta esta inactiva.");

                // Obtener placa del vehiculo del combo
                String selVehiculo = (String) cmbPlaca.getSelectedItem();
                if (selVehiculo == null || selVehiculo.startsWith("--"))
                    throw new Exception("Seleccione un vehiculo de la lista.");
                String placaSeleccionada = selVehiculo.split(" \\| ")[0].trim();
                Vehiculo vehiculo = ctrlVehiculo.buscarPorPlaca(placaSeleccionada);
                if (vehiculo == null)        throw new Exception("Vehiculo no encontrado.");
                if (!vehiculo.isOperativo()) throw new Exception("El vehiculo esta fuera de servicio.");

                // Validar que el asiento no supere la capacidad del vehiculo
                try {
                    int nroAsiento = Integer.parseInt(tfAsiento.getText().trim());
                    if (nroAsiento < 1 || nroAsiento > vehiculo.getCapacidadPasajeros())
                        throw new Exception("Asiento " + nroAsiento + " invalido. El vehiculo " +
                            vehiculo.getPlaca() + " tiene " + vehiculo.getCapacidadPasajeros() +
                            " asientos (1 - " + vehiculo.getCapacidadPasajeros() + ").");
                } catch (NumberFormatException ex) {
                    throw new Exception("El numero de asiento debe ser un valor numerico.");
                }

                // Obtener licencia del conductor del combo
                String selConductor = (String) cmbLicencia.getSelectedItem();
                if (selConductor == null || selConductor.startsWith("--"))
                    throw new Exception("Seleccione un conductor de la lista.");
                String licenciaSeleccionada = selConductor.split(" \\| ")[0].trim();
                Conductor conductor = ctrlConductor.buscarPorLicencia(licenciaSeleccionada);
                if (conductor == null)         throw new Exception("Conductor no encontrado.");
                if (!conductor.isDisponible()) throw new Exception("El conductor no esta disponible.");

                LocalDate fecha;
                LocalTime hora;
                try {
                    fecha = LocalDate.parse(tfFecha.getText().trim());
                } catch (DateTimeParseException ex) {
                    throw new Exception("Formato de fecha invalido. Use: YYYY-MM-DD");
                }
                try {
                    hora = LocalTime.parse(tfHora.getText().trim(), DateTimeFormatter.ofPattern("HH:mm"));
                } catch (DateTimeParseException ex) {
                    throw new Exception("Formato de hora invalido. Use: HH:mm");
                }

                // Validar telefono obligatorio con exactamente 9 digitos
                String telefonoTexto = tfTelefono.getText().trim();
                if (telefonoTexto.isEmpty())
                    throw new Exception("El telefono del cliente es obligatorio.");
                if (telefonoTexto.length() != 9)
                    throw new Exception("El telefono debe tener exactamente 9 digitos.");
                if (!telefonoTexto.startsWith("9"))
                    throw new Exception("El telefono debe comenzar con 9.");

                Cliente cliente = new Cliente();
                cliente.setTipoDocumento((String) cmbTipoDoc.getSelectedItem());
                cliente.setNroDocumento(tfNroDoc.getText());
                cliente.setNombre(tfNombre.getText());
                cliente.setApe_paterno(tfPaterno.getText());
                cliente.setApe_materno(tfMaterno.getText());
                cliente.setTelefono(tfTelefono.getText());
                cliente.setTipoCliente((String) cmbTipoCliente.getSelectedItem());

                double dscAuto     = cliente.obtenerDescuentoPorTipo();
                double dscAdicional = parseDouble(tfDescAdicional.getText(), "Descuento adicional");
                double recargo      = parseDouble(tfRecargo.getText(), "Recargo");

                String nroBoleto = "BOL-" + String.format("%04d", ctrlBoleto.getTotalBoletos() + 1);
                Boleto boleto = new Boleto();
                boleto.setNroBoleto(nroBoleto);
                boleto.setRuta(ruta); boleto.setVehiculo(vehiculo); boleto.setConductor(conductor);
                boleto.setCliente(cliente); boleto.setFechaViaje(fecha); boleto.setHoraViaje(hora);
                boleto.setAsiento(tfAsiento.getText());
                boleto.setDescuento(dscAuto + dscAdicional);
                boleto.setRecargo(recargo);
                boleto.calcularTotal();
                ctrlBoleto.agregar_boleto(boleto);
                refrescarTablaBoletos();
                actualizarDashboard();

                JOptionPane.showMessageDialog(this,
                    "✅ Boleto emitido exitosamente\n\n" +
                    "NRO: " + nroBoleto + "\n" +
                    "Ruta: " + ruta.getOrigen() + " → " + ruta.getDestino() + "\n" +
                    "Cliente: " + cliente.getNombreCompleto() + "\n" +
                    "Asiento: " + tfAsiento.getText() + "\n" +
                    "Fecha: " + fecha + " " + hora + "\n" +
                    "Descuento total: " + (dscAuto + dscAdicional) + "%" + "\n" +
                    "TOTAL: S/. " + String.format("%.2f", boleto.getMontoTotal()),
                    "Boleto Emitido", JOptionPane.INFORMATION_MESSAGE);

                btnLimpiar.doClick();
            } catch (Exception ex) {
                mostrarError("Error al emitir: " + ex.getMessage());
            }
        });

        btnLimpiar.addActionListener(e -> {
            cmbRuta.setSelectedIndex(0);
            cmbPlaca.setSelectedIndex(0);
            cmbLicencia.setSelectedIndex(0);
            tfAsiento.setText("");
            tfFecha.setText(LocalDate.now().toString());
            tfHora.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
            tfNroDoc.setText(""); tfNombre.setText(""); tfPaterno.setText("");
            tfMaterno.setText(""); tfTelefono.setText(""); tfDescAdicional.setText("0");
            tfRecargo.setText("0"); lblInfo.setText(" ");
        });

        JScrollPane scroll = new JScrollPane(formCard);
        scroll.setBorder(null);
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PANEL BOLETOS
    // ═══════════════════════════════════════════════════════════════════════════
    private JPanel crearPanelBoletos() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(C_FONDO);
        panel.setBorder(new EmptyBorder(16, 16, 16, 16));

        String[] cols = {"N° Boleto","Fecha","Hora","Origen","Destino","Cliente",
                         "Doc.","N° Documento","Telefono",
                         "Vehiculo","Asiento","Desc.%","Recargo%","Total","Estado"};
        modeloTablaBoletos = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tabla = crearTabla(modeloTablaBoletos);

        // Reporte
        JPanel panelReporte = crearCard("Reporte de Ventas");
        panelReporte.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
        JLabel lblResumen = new JLabel("Seleccione un boleto o genere el reporte.");
        lblResumen.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        panelReporte.add(lblResumen);

        JButton btnReporte  = crearBotonPrimario("📊 Generar Reporte");
        JButton btnCancelar = crearBotonRojo("❌ Cancelar Boleto");
        JButton btnRefresh  = crearBotonSecundario("↻ Refrescar");
        JButton btnDetalle  = crearBotonSecundario("🔍 Ver Detalle Completo");

        btnDetalle.addActionListener(e -> {
            int f = tabla.getSelectedRow();
            if (f < 0) { mostrarError("Seleccione un boleto."); return; }
            String nro = (String) modeloTablaBoletos.getValueAt(f, 0);
            Boleto b = ctrlBoleto.buscarPorNro(nro);
            if (b == null) return;

            String detalle =
                "═══════ DETALLE DEL BOLETO ═══════\n\n" +
                "N° Boleto:      " + b.getNroBoleto() + "\n" +
                "Estado:         " + (b.isCancelado() ? "Cancelado" : "Activo") + "\n\n" +
                "── Datos del Viaje ──\n" +
                "Ruta:           " + b.getRuta().getOrigen() + " → " + b.getRuta().getDestino() + "\n" +
                "Fecha:          " + b.getFechaViaje() + "\n" +
                "Hora:           " + b.getHoraViaje() + "\n" +
                "Asiento:        " + b.getAsiento() + "\n" +
                "Vehiculo:       " + b.getVehiculo().getMarca() + " " + b.getVehiculo().getModelo() +
                                     " (" + b.getVehiculo().getPlaca() + ")\n" +
                "Conductor:      " + b.getConductor().getNombreCompleto() + "\n\n" +
                "── Datos del Cliente ──\n" +
                "Nombre:         " + b.getCliente().getNombreCompleto() + "\n" +
                "Tipo Doc:       " + b.getCliente().getTipoDocumento() + "\n" +
                "N° Documento:   " + b.getCliente().getNroDocumento() + "\n" +
                "Telefono:       " + b.getCliente().getTelefono() + "\n" +
                "Tipo Cliente:   " + b.getCliente().getTipoCliente() + "\n\n" +
                "── Datos de Pago ──\n" +
                "Descuento:      " + b.getDescuento() + "%\n" +
                "Recargo:        " + b.getRecargo() + "%\n" +
                "TOTAL:          S/. " + String.format("%.2f", b.getMontoTotal());

            JTextArea area = new JTextArea(detalle);
            area.setEditable(false);
            area.setFont(new Font("Consolas", Font.PLAIN, 13));
            area.setBackground(C_FONDO);
            JScrollPane sp = new JScrollPane(area);
            sp.setPreferredSize(new Dimension(420, 420));
            JOptionPane.showMessageDialog(this, sp,
                "Detalle del Boleto " + nro, JOptionPane.PLAIN_MESSAGE);
        });

        // Doble clic en la tabla tambien abre el detalle
        tabla.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) btnDetalle.doClick();
            }
        });

        btnRefresh.addActionListener(e -> refrescarTablaBoletos());
        btnCancelar.addActionListener(e -> {
            int f = tabla.getSelectedRow(); if(f<0){mostrarError("Seleccione un boleto.");return;}
            String nro = (String) modeloTablaBoletos.getValueAt(f,0);
            Boleto b = ctrlBoleto.buscarPorNro(nro);
            if (b == null) return;
            if (b.isCancelado()) { mostrarError("El boleto ya esta cancelado."); return; }
            if (confirmar("¿Cancelar el boleto " + nro + "?")) {
                ctrlBoleto.cancelarBoleto(nro); refrescarTablaBoletos(); actualizarDashboard();
                mostrarExito("Boleto cancelado.");
            }
        });
        btnReporte.addActionListener(e -> {
            lblResumen.setText(
                "Total boletos: " + ctrlBoleto.getTotalBoletos() +
                "   |   Activos: " + ctrlBoleto.getBoletosActivos() +
                "   |   Cancelados: " + ctrlBoleto.getBoletosCancelados() +
                "   |   Recaudado: S/. " + String.format("%.2f", ctrlBoleto.getTotalRecaudado()));
        });

        JPanel bots = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        bots.setBackground(C_FONDO);
        bots.add(btnRefresh); bots.add(btnDetalle); bots.add(btnCancelar); bots.add(btnReporte);

        panel.add(panelReporte, BorderLayout.NORTH);
        panel.add(new JScrollPane(tabla), BorderLayout.CENTER);
        panel.add(bots, BorderLayout.SOUTH);

        refrescarTablaBoletos();
        return panel;
    }

    private void refrescarTablaBoletos() {
        modeloTablaBoletos.setRowCount(0);
        for (int i = 0; i < ctrlBoleto.boletos.size(); i++) {
            Boleto b = ctrlBoleto.boletos.get(i);
            modeloTablaBoletos.addRow(new Object[]{
                b.getNroBoleto(), b.getFechaViaje(),
                b.getHoraViaje().format(DateTimeFormatter.ofPattern("HH:mm")),
                b.getRuta().getOrigen(), b.getRuta().getDestino(),
                b.getCliente().getNombreCompleto(),
                b.getCliente().getTipoDocumento(),
                b.getCliente().getNroDocumento(),
                b.getCliente().getTelefono(),
                b.getVehiculo().getMarca() + " " + b.getVehiculo().getModelo() +
                    " (" + b.getVehiculo().getPlaca() + ")",
                b.getAsiento(),
                b.getDescuento() + "%", b.getRecargo() + "%",
                "S/. " + String.format("%.2f", b.getMontoTotal()),
                b.isCancelado() ? "Cancelado" : "Activo"
            });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // UTILIDADES DE UI
    // ═══════════════════════════════════════════════════════════════════════════
    private JPanel crearCard(String titulo) {
        JPanel card = new JPanel();
        card.setBackground(C_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(C_BORDER, 1, true),
                titulo, javax.swing.border.TitledBorder.LEFT,
                javax.swing.border.TitledBorder.TOP,
                new Font("Segoe UI", Font.BOLD, 13), C_PRIMARIO),
            new EmptyBorder(8, 12, 12, 12)
        ));
        return card;
    }

    private JTable crearTabla(DefaultTableModel modelo) {
    JTable tabla = new JTable(modelo);
    tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    tabla.setRowHeight(26);
    tabla.setGridColor(C_BORDER);
    tabla.setSelectionBackground(new Color(219, 234, 254));
    tabla.setSelectionForeground(C_TEXTO);
    tabla.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

    JTableHeader header = tabla.getTableHeader();
    header.setFont(new Font("Segoe UI", Font.BOLD, 12));
    header.setBackground(C_PRIMARIO);
    header.setForeground(Color.WHITE);
    header.setOpaque(true);
    header.setDefaultRenderer(new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object val,
                boolean sel, boolean foc, int row, int col) {
            JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, val, sel, foc, row, col);
            lbl.setBackground(C_PRIMARIO);
            lbl.setForeground(Color.WHITE);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lbl.setOpaque(true);
            lbl.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 1, new Color(13, 27, 62)),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            return lbl;
        }
    });
    return tabla;
    }

    private JTextField nuevoTF() { return nuevoTF(""); }
    private JTextField nuevoTF(String texto) {
        JTextField tf = new JTextField(texto);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(C_BORDER, 1, true),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        tf.setPreferredSize(new Dimension(150, 30));
        return tf;
    }

    private JLabel lblCampo(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(C_TEXTO);
        return lbl;
    }

    private JButton crearBotonPrimario(String texto) {
    JButton btn = new JButton(texto) {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(C_PRIMARIO);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
            g2.dispose();
            super.paintComponent(g);
        }
    };
    btn.setForeground(Color.WHITE);
    btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
    btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
    btn.setFocusPainted(false);
    btn.setContentAreaFilled(false);
    btn.setOpaque(false);
    btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    return btn;
    }

    private JButton crearBotonSecundario(String texto) {
    JButton btn = new JButton(texto) {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(241, 245, 249));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
            g2.setColor(C_BORDER);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 6, 6);
            g2.dispose();
            super.paintComponent(g);
        }
    };
    btn.setForeground(C_TEXTO);
    btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
    btn.setFocusPainted(false);
    btn.setContentAreaFilled(false);
    btn.setOpaque(false);
    btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    return btn;
    }

    private JButton crearBotonRojo(String texto) {
    JButton btn = new JButton(texto) {
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(C_ROJO);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
            g2.dispose();
            super.paintComponent(g);
        }
    };
    btn.setForeground(Color.WHITE);
    btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
    btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
    btn.setFocusPainted(false);
    btn.setContentAreaFilled(false);
    btn.setOpaque(false);
    btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    return btn;
    }

    private void estilizarBotonHeader(JButton btn) {
        btn.setBackground(new Color(255, 255, 255, 40));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(255,255,255,80), 1),
            BorderFactory.createEmptyBorder(6, 14, 6, 14)));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
    }

    private void mostrarExito(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Exito", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private boolean confirmar(String msg) {
        return JOptionPane.showConfirmDialog(this, msg, "Confirmacion",
            JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    private double parseDouble(String s, String campo) {
        try {
            return Double.parseDouble(s.trim().replace(",", "."));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Valor invalido en campo '" + campo + "': " + s);
        }
    }

    private void cerrarSesion() {
        if (confirmar("¿Desea cerrar sesion?")) {
            dispose();
            SwingUtilities.invokeLater(() -> {
                ControladorVendedor ctrl = new ControladorVendedor();
                new LoginGUI(ctrl).setVisible(true);
            });
        }
    }
}
