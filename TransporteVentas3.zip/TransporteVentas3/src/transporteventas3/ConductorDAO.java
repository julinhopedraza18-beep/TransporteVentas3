/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.sql.*;
import java.util.ArrayList;

public class ConductorDAO {

    // CREATE
    public boolean insertar(Conductor c) {
        String sqlPersona = "INSERT INTO personas (tipo_documento, nro_documento, nombre, ape_paterno, ape_materno, telefono) " +
                            "VALUES (?, ?, ?, ?, ?, ?); SELECT SCOPE_IDENTITY();";
        String sqlConductor = "INSERT INTO conductores (id_persona, nro_licencia, categoria_licencia, disponible) " +
                              "VALUES (?, ?, ?, ?)";
        try (Connection con = ConexionDB.getConexion()) {
            // Insertar persona y obtener ID generado
            PreparedStatement ps1 = con.prepareStatement(sqlPersona);
            ps1.setString(1, c.getTipoDocumento());
            ps1.setString(2, c.getNroDocumento());
            ps1.setString(3, c.getNombre());
            ps1.setString(4, c.getApe_paterno());
            ps1.setString(5, c.getApe_materno());
            ps1.setString(6, c.getTelefono());
            ResultSet rs = ps1.executeQuery();
            int idPersona = 0;
            if (rs.next()) idPersona = rs.getInt(1);

            // Insertar conductor
            PreparedStatement ps2 = con.prepareStatement(sqlConductor);
            ps2.setInt    (1, idPersona);
            ps2.setString (2, c.getNroLicencia());
            ps2.setString (3, c.getCategoriaLicencia());
            ps2.setBoolean(4, c.isDisponible());
            ps2.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al insertar conductor: " + e.getMessage());
            return false;
        }
    }

    // READ
    public ArrayList<Conductor> listarTodos() {
        ArrayList<Conductor> lista = new ArrayList<>();
        String sql = "SELECT p.*, c.nro_licencia, c.categoria_licencia, c.disponible " +
                     "FROM conductores c INNER JOIN personas p ON c.id_persona = p.id_persona " +
                     "ORDER BY p.ape_paterno";
        try (Connection con = ConexionDB.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Conductor c = new Conductor();
                c.setTipoDocumento(rs.getString("tipo_documento"));
                c.setNroDocumento(rs.getString("nro_documento"));
                c.setNombre(rs.getString("nombre"));
                c.setApe_paterno(rs.getString("ape_paterno"));
                c.setApe_materno(rs.getString("ape_materno"));
                c.setTelefono(rs.getString("telefono"));
                c.setNroLicencia(rs.getString("nro_licencia"));
                c.setCategoriaLicencia(rs.getString("categoria_licencia"));
                c.setDisponible(rs.getBoolean("disponible"));
                lista.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar conductores: " + e.getMessage());
        }
        return lista;
    }

    public Conductor buscarPorLicencia(String licencia) {
        String sql = "SELECT p.*, c.nro_licencia, c.categoria_licencia, c.disponible " +
                     "FROM conductores c INNER JOIN personas p ON c.id_persona = p.id_persona " +
                     "WHERE c.nro_licencia = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, licencia);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Conductor c = new Conductor();
                c.setTipoDocumento(rs.getString("tipo_documento"));
                c.setNroDocumento(rs.getString("nro_documento"));
                c.setNombre(rs.getString("nombre"));
                c.setApe_paterno(rs.getString("ape_paterno"));
                c.setApe_materno(rs.getString("ape_materno"));
                c.setTelefono(rs.getString("telefono"));
                c.setNroLicencia(rs.getString("nro_licencia"));
                c.setCategoriaLicencia(rs.getString("categoria_licencia"));
                c.setDisponible(rs.getBoolean("disponible"));
                return c;
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar conductor: " + e.getMessage());
        }
        return null;
    }

    // UPDATE
    public boolean actualizarDisponibilidad(String licencia, boolean disponible) {
        String sql = "UPDATE conductores SET disponible = ? WHERE nro_licencia = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, disponible);
            ps.setString(2, licencia);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al actualizar conductor: " + e.getMessage());
            return false;
        }
    }

    // DELETE
    public boolean eliminar(String licencia) {
        String sql = "DELETE FROM conductores WHERE nro_licencia = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, licencia);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al eliminar conductor: " + e.getMessage());
            return false;
        }
    }
}
