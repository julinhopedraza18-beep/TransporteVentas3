/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

/**
 *
 * @author julin
 */
public class Conbi extends Vehiculo {
    private String tipoRuta;
    private boolean tieneMusica;

    public String getTipoRuta() { return tipoRuta; }
    public void setTipoRuta(String tipoRuta) {
        if (tipoRuta == null || (!tipoRuta.equalsIgnoreCase("urbana") &&
            !tipoRuta.equalsIgnoreCase("interdistrital") &&
            !tipoRuta.equalsIgnoreCase("rural")))
            throw new IllegalArgumentException("Tipo de ruta: urbana / interdistrital / rural.");
        this.tipoRuta = tipoRuta.toLowerCase();
    }

    public boolean isTieneMusica() { return tieneMusica; }
    public void setTieneMusica(boolean tieneMusica) { this.tieneMusica = tieneMusica; }

    @Override
    public void validarCapacidad() {
        if (capacidadPasajeros > 20)
            throw new IllegalArgumentException(
                "Una combi permite maximo 20 pasajeros.");
        if (capacidadPasajeros <= 0)
            throw new IllegalArgumentException("La capacidad debe ser mayor a 0.");
    }

    @Override
    public void ver_datos() {
        String estado = isOperativo() ? "" : " [FUERA DE SERVICIO]";
        System.out.println("Combi MARCA: " + marca + " MODELO: " + modelo +
            " ANIO: " + anio + " PLACA: " + placa +
            " CAPACIDAD: " + capacidadPasajeros + " pasajeros" +
            " CATEGORIA: " + determinarCategoria() +
            " TIPO RUTA: " + tipoRuta +
            " MUSICA: " + (tieneMusica ? "Si" : "No") + estado);
    }
}
