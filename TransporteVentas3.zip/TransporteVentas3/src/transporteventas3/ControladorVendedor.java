/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.util.ArrayList;

public class ControladorVendedor {
    ArrayList<UsuarioSistema> usuarios = new ArrayList<>();
    private VendedorDAO dao = new VendedorDAO();

    public ControladorVendedor() {
        // Datos de respaldo si BD no está disponible
        usuarios.add(new Administrador("admin",     "admin123",  "Administrador", "Sistema",  "900000001"));
        usuarios.add(new Vendedor     ("vendedor1", "venta2024", "Juan",          "Perez",    "900000002"));
        usuarios.add(new Supervisor   ("supervisor","super2024", "Maria",         "Torres",   "900000003"));
    }

    public UsuarioSistema autenticar(String username, String password) {
        // Primero intenta autenticar desde la BD
        UsuarioSistema u = dao.autenticar(username, password);
        if (u != null) return u;
        // Si falla BD, usa la lista local
        for (int i = 0; i < usuarios.size(); i++) {
            UsuarioSistema us = usuarios.get(i);
            if (us.getUsername().equalsIgnoreCase(username)
                && us.verificarPassword(password)
                && us.isActivo()) {
                return us;
            }
        }
        return null;
    }

    public int getTotalUsuarios() { return usuarios.size(); }
}