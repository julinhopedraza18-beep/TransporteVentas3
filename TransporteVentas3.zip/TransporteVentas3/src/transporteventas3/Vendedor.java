/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

public class Vendedor extends Persona implements UsuarioSistema {   
    private String username;
    private String password;
    private final String rol = "vendedor";
    private boolean activo = true;

    public Vendedor() {}

    public Vendedor(String username, String password,
                    String nombre, String ape_paterno, String telefono) {
        setUsername(username);
        setPassword(password);
        this.nombre      = nombre;
        this.ape_paterno = ape_paterno;
        this.telefono    = telefono;
    }

    public String getUsername() { return username; }
    public void setUsername(String username) {
        if (username == null || username.trim().isEmpty())
            throw new IllegalArgumentException("El usuario no puede estar vacio.");
        this.username = username.trim().toLowerCase();
    }

    public String getPassword() { return password; }
    public void setPassword(String password) {
        if (password == null || password.length() < 4)
            throw new IllegalArgumentException("La contrasena debe tener al menos 4 caracteres.");
        this.password = password;
    }

    public String getRol() { return rol; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public boolean verificarPassword(String intento) {
        return this.password.equals(intento);
    }

    @Override
    public void ver_datos() {
        System.out.println("Vendedor: " + username +
            " | Nombre: " + getNombreCompleto() +
            " | Rol: " + rol + " | Activo: " + activo);
    }
}