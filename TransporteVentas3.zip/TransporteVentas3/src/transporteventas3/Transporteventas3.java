/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package transporteventas3;

import javax.swing.*;

/**
 * Punto de entrada principal del Sistema de Ventas.
 * Lanza la interfaz grafica con pantalla de login.
 */
public class Transporteventas3 {

    public static void main(String[] args) {
        
        // Aplicar look and feel del sistema operativo para mejor apariencia
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        // Ajustes globales de fuente para toda la aplicacion
        UIManager.put("Button.font",          new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        UIManager.put("Label.font",           new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        UIManager.put("TextField.font",       new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        UIManager.put("ComboBox.font",        new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        UIManager.put("Table.font",           new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 12));
        UIManager.put("TableHeader.font",     new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12));
        UIManager.put("TabbedPane.font",      new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));
        UIManager.put("OptionPane.messageFont", new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13));

        // Iniciar controlador de usuarios y mostrar login
        SwingUtilities.invokeLater(() -> {
            ControladorVendedor ctrlVendedor = new ControladorVendedor();
            LoginGUI login = new LoginGUI(ctrlVendedor);
            login.setVisible(true);
        });
    }
}

