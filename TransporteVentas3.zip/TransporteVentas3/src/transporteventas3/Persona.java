/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

public abstract class Persona {
    protected String tipoDocumento;
    protected String nroDocumento;
    protected String nombre;
    protected String ape_paterno;
    protected String ape_materno;
    protected String telefono;

    public String getTipoDocumento() { return tipoDocumento; }
    public void setTipoDocumento(String tipoDocumento) {
        if (tipoDocumento == null || tipoDocumento.trim().isEmpty())
            throw new IllegalArgumentException("Tipo de documento invalido.");
        this.tipoDocumento = tipoDocumento.toUpperCase().trim();
    }

    public String getNroDocumento() { return nroDocumento; }
    public void setNroDocumento(String nroDocumento) {
        if (nroDocumento == null || nroDocumento.trim().isEmpty())
            throw new IllegalArgumentException("El nro de documento no puede estar vacio.");
        this.nroDocumento = nroDocumento.trim();
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty())
            throw new IllegalArgumentException("El nombre no puede estar vacio.");
        String n = nombre.trim();
        if (!n.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+"))
            throw new IllegalArgumentException("El nombre solo puede contener letras.");
        if (n.length() < 2)
            throw new IllegalArgumentException("El nombre debe tener al menos 2 caracteres.");
        this.nombre = n;
    }

    public String getApe_paterno() { return ape_paterno; }
    public void setApe_paterno(String ape_paterno) {
        if (ape_paterno == null || ape_paterno.trim().isEmpty())
            throw new IllegalArgumentException("El apellido paterno no puede estar vacio.");
        String ap = ape_paterno.trim();
        if (!ap.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+"))
            throw new IllegalArgumentException("El apellido paterno solo puede contener letras.");
        if (ap.length() < 2)
            throw new IllegalArgumentException("El apellido paterno debe tener al menos 2 caracteres.");
        this.ape_paterno = ap;
    }

    public String getApe_materno() { return ape_materno; }
    public void setApe_materno(String ape_materno) {
        if (ape_materno != null && !ape_materno.trim().isEmpty()) {
            String am = ape_materno.trim();
            if (!am.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+"))
                throw new IllegalArgumentException("El apellido materno solo puede contener letras.");
            this.ape_materno = am;
        } else {
            this.ape_materno = ape_materno;
        }
    }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) {
        if (telefono != null && !telefono.trim().isEmpty()) {
            String tel = telefono.trim();
            if (!tel.matches("\\d+"))
                throw new IllegalArgumentException("El telefono solo puede contener numeros.");
            if (tel.length() != 9)
                throw new IllegalArgumentException("El telefono debe tener exactamente 9 digitos.");
            if (!tel.startsWith("9"))
                throw new IllegalArgumentException("El telefono debe comenzar con 9.");
            this.telefono = tel;
        } else {
            this.telefono = telefono;
        }
    }

    public String getNombreCompleto() {
        return nombre + " " + ape_paterno +
               (ape_materno != null && !ape_materno.isEmpty() ? " " + ape_materno : "");
    }

    public abstract void ver_datos();
}
