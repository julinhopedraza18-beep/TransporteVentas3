/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.util.ArrayList;

public class ControladorConductor {
    ArrayList<Conductor> conductores = new ArrayList<>();
    private ConductorDAO dao = new ConductorDAO();

    public ControladorConductor() {
        conductores = dao.listarTodos();
    }

    public void agregar_conductor(Conductor nuevoConductor) {
        if (nuevoConductor == null)
            throw new IllegalArgumentException("El conductor no puede ser nulo.");
        if (buscarPorLicencia(nuevoConductor.getNroLicencia()) != null)
            throw new IllegalArgumentException("Ya existe un conductor con la licencia: " + nuevoConductor.getNroLicencia());
        dao.insertar(nuevoConductor);
        conductores.add(nuevoConductor);
    }

    public void listar_conductores() {
        for (int i = 0; i < conductores.size(); i++) {
            conductores.get(i).ver_datos();
        }
    }

    public Conductor buscarPorLicencia(String licencia) {
        for (int i = 0; i < conductores.size(); i++) {
            if (conductores.get(i).getNroLicencia().equalsIgnoreCase(licencia)) {
                return conductores.get(i);
            }
        }
        return null;
    }

    public boolean eliminarPorLicencia(String licencia) {
        dao.eliminar(licencia);
        for (int i = 0; i < conductores.size(); i++) {
            if (conductores.get(i).getNroLicencia().equalsIgnoreCase(licencia)) {
                conductores.remove(i);
                return true;
            }
        }
        return false;
    }

    public void actualizarDisponibilidad(String licencia, boolean disponible) {
        dao.actualizarDisponibilidad(licencia, disponible);
        Conductor c = buscarPorLicencia(licencia);
        if (c != null) c.setDisponible(disponible);
    }

    public int getTotalConductores() { return conductores.size(); }

    public int getTotalDisponibles() {
        int count = 0;
        for (int i = 0; i < conductores.size(); i++) {
            if (conductores.get(i).isDisponible()) count++;
        }
        return count;
    }
}