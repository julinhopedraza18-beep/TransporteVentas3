/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

public class Conductor extends Persona {
    private String nroLicencia;
    private String categoriaLicencia;
    private boolean disponible = true;

    @Override
    public void setNroDocumento(String nroDocumento) {
        if (nroDocumento == null || nroDocumento.trim().isEmpty())
            throw new IllegalArgumentException("El nro de documento no puede estar vacio.");
        String nro = nroDocumento.trim();
        if (tipoDocumento != null && tipoDocumento.equalsIgnoreCase("DNI")) {
            if (!nro.matches("\\d+"))
                throw new IllegalArgumentException("El DNI solo debe contener numeros.");
            if (nro.length() != 8)
                throw new IllegalArgumentException("El DNI debe tener exactamente 8 digitos.");
        } else if (tipoDocumento != null && tipoDocumento.equalsIgnoreCase("CE")) {
            if (nro.length() > 12)
                throw new IllegalArgumentException("El CE no puede superar 12 caracteres.");
        }
        this.nroDocumento = nro;
    }

    public String getNroLicencia() { return nroLicencia; }
    public void setNroLicencia(String nroLicencia) {
        if (nroLicencia == null || nroLicencia.trim().isEmpty())
            throw new IllegalArgumentException("El nro de licencia no puede estar vacio.");
        this.nroLicencia = nroLicencia.trim();
    }

    public String getCategoriaLicencia() { return categoriaLicencia; }
    public void setCategoriaLicencia(String categoriaLicencia) {
        if (categoriaLicencia == null || (!categoriaLicencia.equalsIgnoreCase("A-IIa") &&
            !categoriaLicencia.equalsIgnoreCase("A-IIb") &&
            !categoriaLicencia.equalsIgnoreCase("A-IIIa") &&
            !categoriaLicencia.equalsIgnoreCase("A-IIIb") &&
            !categoriaLicencia.equalsIgnoreCase("A-IIIc")))
            throw new IllegalArgumentException("Categoria invalida (A-IIa/A-IIb/A-IIIa/A-IIIb/A-IIIc).");
        this.categoriaLicencia = categoriaLicencia.toUpperCase();
    }

    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }

    @Override
    public void ver_datos() {
        String estado = isDisponible() ? "" : " [NO DISPONIBLE]";
        System.out.println("Conductor TIPODOC: " + tipoDocumento +
            " NRODOC: " + nroDocumento +
            " NOMBRE: " + getNombreCompleto() +
            " TELEFONO: " + telefono +
            " LICENCIA: " + nroLicencia +
            " CATEGORIA: " + categoriaLicencia + estado);
    }
}