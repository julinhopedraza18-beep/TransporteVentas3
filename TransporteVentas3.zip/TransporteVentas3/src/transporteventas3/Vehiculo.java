/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;


public abstract class Vehiculo {
    protected String marca;
    protected String modelo;
    protected int anio;
    protected String placa;
    protected int capacidadPasajeros;
    protected boolean operativo = true;

    // Marcas de vehiculos reconocidas en el Peru
    private static final String[] MARCAS_VALIDAS = {
        "MERCEDES-BENZ", "VOLVO", "SCANIA", "HINO", "YUTONG",
        "TOYOTA", "NISSAN", "HYUNDAI", "VOLKSWAGEN", "MAN",
        "IVECO", "DAEWOO", "KIA", "MITSUBISHI", "ISUZU",
        "ZHONGTONG", "KING LONG", "GOLDEN DRAGON", "ANKAI",
        "FORD", "CHEVROLET", "JAC", "DONGFENG", "FOTON",
        "MARCOPOLO", "IRIZAR", "COMIL", "BUSSCAR"
    };

    public String getMarca() { return marca; }
    public void setMarca(String marca) {
        if (marca == null || marca.trim().isEmpty())
            throw new IllegalArgumentException("La marca no puede estar vacia.");
        String m = marca.trim().toUpperCase();
        boolean valida = false;
        for (int i = 0; i < MARCAS_VALIDAS.length; i++) {
            if (MARCAS_VALIDAS[i].equals(m)) {
                valida = true;
                break;
            }
        }
        if (!valida)
            throw new IllegalArgumentException(
                "Marca no reconocida: " + marca + ".\nMarcas permitidas: " +
                "Mercedes-Benz, Volvo, Scania, Hino, Yutong, Toyota, Nissan, " +
                "Hyundai, Volkswagen, MAN, Iveco, Daewoo, Kia, Mitsubishi, " +
                "Isuzu, Zhongtong, King Long, Golden Dragon, Ankai, Ford, " +
                "Chevrolet, JAC, Dongfeng, Foton, Marcopolo, Irizar, Comil, Busscar.");
        this.marca = marca.trim();
    }
    public String getModelo() { return modelo; }
    public void setModelo(String modelo) {
        if (modelo == null || modelo.trim().isEmpty())
            throw new IllegalArgumentException("El modelo no puede estar vacio.");
        this.modelo = modelo;
    }

    public int getAnio() { return anio; }
    public void setAnio(int anio) {
        if (anio < 1990 || anio > 2026)
            throw new IllegalArgumentException("Anio invalido. Rango permitido: 1990 - 2026.");
        this.anio = anio;
    }

    public String getPlaca() { return placa; }
    public void setPlaca(String placa) {
        if (placa == null || placa.trim().isEmpty())
            throw new IllegalArgumentException("La placa no puede estar vacia.");
        String p = placa.toUpperCase().trim();
        if (!p.matches("[A-Z0-9]{3}-[A-Z0-9]{3}"))
            throw new IllegalArgumentException(
                "Formato de placa invalido. Debe ser 3 caracteres, guion, 3 caracteres. Ejemplo: J2R-34M");
        String sinGuion = p.replace("-", "");
        boolean tieneLetras  = sinGuion.matches(".*[A-Z].*");
        boolean tieneNumeros = sinGuion.matches(".*[0-9].*");
        if (!tieneLetras || !tieneNumeros)
            throw new IllegalArgumentException(
                "La placa debe combinar letras y numeros obligatoriamente. Ejemplo: J2R-34M");
        this.placa = p;
    }

    public int getCapacidadPasajeros() { return capacidadPasajeros; }
    public void setCapacidadPasajeros(int capacidadPasajeros) {
        if (capacidadPasajeros <= 0)
            throw new IllegalArgumentException("La capacidad debe ser mayor a 0.");
        this.capacidadPasajeros = capacidadPasajeros;
    }

    // Este metodo es sobreescrito por Bus con validacion por pisos
    public void validarCapacidad() {}

    public boolean isOperativo() { return operativo; }
    public void setOperativo(boolean operativo) { this.operativo = operativo; }

    public String determinarCategoria() {
        if (capacidadPasajeros <= 15)      return "Combi";
        else if (capacidadPasajeros <= 40) return "Bus Mediano";
        else                               return "Bus Grande";
    }

    public abstract void ver_datos();
}

