/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.sql.*;
import java.util.ArrayList;

public class RutaDAO {

    // CREATE
    public boolean insertar(Ruta r) {
        // Verificar si ya existe una ruta con el mismo origen y destino
        String sqlVerificar = "SELECT COUNT(*) FROM rutas WHERE LOWER(origen) = LOWER(?) AND LOWER(destino) = LOWER(?) AND activa = 1";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement psV = con.prepareStatement(sqlVerificar)) {
            psV.setString(1, r.getOrigen());
            psV.setString(2, r.getDestino());
            ResultSet rsV = psV.executeQuery();
            if (rsV.next() && rsV.getInt(1) > 0) {
                throw new IllegalArgumentException(
                    "Ya existe una ruta activa de " + r.getOrigen() +
                    " a " + r.getDestino() + ". No se puede duplicar la misma ruta.");
            }
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (SQLException e) {
            System.err.println("Error al verificar ruta: " + e.getMessage());
            return false;
        }
        
        String sql = "INSERT INTO rutas (codigo_ruta, origen, destino, distancia_km, duracion_minutos, precio_base, activa) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, r.getCodigoRuta());
            ps.setString(2, r.getOrigen());
            ps.setString(3, r.getDestino());
            ps.setDouble(4, r.getDistanciaKm());
            ps.setInt   (5, r.getDuracionMinutos());
            ps.setDouble(6, r.getPrecioPasajeBase());
            ps.setBoolean(7, r.isActiva());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al insertar ruta: " + e.getMessage());
            return false;
        }
    }

    // READ
    public ArrayList<Ruta> listarTodas() {
        ArrayList<Ruta> lista = new ArrayList<>();
        String sql = "SELECT * FROM rutas ORDER BY codigo_ruta";
        try (Connection con = ConexionDB.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Ruta r = new Ruta();
                r.setCodigoRuta(rs.getString("codigo_ruta"));
                r.setOrigen(rs.getString("origen"));
                r.setDestino(rs.getString("destino"));
                r.setDistanciaKm(rs.getDouble("distancia_km"));
                r.setDuracionMinutos(rs.getInt("duracion_minutos"));
                r.setPrecioPasajeBase(rs.getDouble("precio_base"));
                r.setActiva(rs.getBoolean("activa"));
                lista.add(r);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar rutas: " + e.getMessage());
        }
        return lista;
    }

    public Ruta buscarPorCodigo(String codigo) {
        String sql = "SELECT * FROM rutas WHERE codigo_ruta = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Ruta r = new Ruta();
                r.setCodigoRuta(rs.getString("codigo_ruta"));
                r.setOrigen(rs.getString("origen"));
                r.setDestino(rs.getString("destino"));
                r.setDistanciaKm(rs.getDouble("distancia_km"));
                r.setDuracionMinutos(rs.getInt("duracion_minutos"));
                r.setPrecioPasajeBase(rs.getDouble("precio_base"));
                r.setActiva(rs.getBoolean("activa"));
                return r;
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar ruta: " + e.getMessage());
        }
        return null;
    }

    // UPDATE
    public boolean actualizarEstado(String codigo, boolean activa) {
        String sql = "UPDATE rutas SET activa = ? WHERE codigo_ruta = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, activa);
            ps.setString(2, codigo);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al actualizar ruta: " + e.getMessage());
            return false;
        }
    }

    // DELETE
    public boolean eliminar(String codigo) {
        String sql = "DELETE FROM rutas WHERE codigo_ruta = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al eliminar ruta: " + e.getMessage());
            return false;
        }
    }
}