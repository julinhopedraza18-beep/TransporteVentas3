/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

public class Cliente extends Persona {
    private String tipoCliente;   // regular / frecuente / corporativo

    @Override
    public void setNroDocumento(String nroDocumento) {
        if (nroDocumento == null || nroDocumento.trim().isEmpty())
            throw new IllegalArgumentException("El nro de documento no puede estar vacio.");
        String nro = nroDocumento.trim();
        if (tipoDocumento != null && tipoDocumento.equalsIgnoreCase("DNI")) {
            if (!nro.matches("\\d+"))
                throw new IllegalArgumentException("El DNI solo debe contener numeros.");
            if (nro.length() != 8)
                throw new IllegalArgumentException("El DNI debe tener exactamente 8 digitos.");
        } else if (tipoDocumento != null && tipoDocumento.equalsIgnoreCase("CE")) {
            if (nro.length() > 12)
                throw new IllegalArgumentException("El CE no puede superar 12 caracteres.");
        }
        this.nroDocumento = nro;
    }

    public String getTipoCliente() { return tipoCliente; }
    public void setTipoCliente(String tipoCliente) {
        if (tipoCliente == null || (!tipoCliente.equalsIgnoreCase("regular") &&
            !tipoCliente.equalsIgnoreCase("frecuente") &&
            !tipoCliente.equalsIgnoreCase("corporativo")))
            throw new IllegalArgumentException("Tipo de cliente: regular / frecuente / corporativo.");
        this.tipoCliente = tipoCliente.toLowerCase();
    }

    public double obtenerDescuentoPorTipo() {
        if (tipoCliente == null) return 0;
        switch (tipoCliente.toLowerCase()) {
            case "frecuente":   return 10.0;
            case "corporativo": return 15.0;
            default:            return 0.0;
        }
    }

    @Override
    public void ver_datos() {
        System.out.println("Cliente TIPODOC: " + tipoDocumento +
            " NRODOC: " + nroDocumento +
            " NOMBRE: " + getNombreCompleto() +
            " TELEFONO: " + telefono +
            " TIPO: " + tipoCliente);
    }
}