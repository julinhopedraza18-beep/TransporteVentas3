/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.sql.*;
import java.util.ArrayList;

public class VehiculoDAO {

    // CREATE
    public boolean insertar(Vehiculo v) {
        String sqlVehiculo = "INSERT INTO vehiculos (tipo, marca, modelo, anio, placa, " +
                             "capacidad_pasajeros, operativo) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?); SELECT SCOPE_IDENTITY();";
        try (Connection con = ConexionDB.getConexion()) {
            // Insertar en tabla vehiculos y obtener id generado
            PreparedStatement ps = con.prepareStatement(sqlVehiculo);
            ps.setString (1, (v instanceof Bus) ? "Bus" : "Combi");
            ps.setString (2, v.getMarca());
            ps.setString (3, v.getModelo());
            ps.setInt    (4, v.getAnio());
            ps.setString (5, v.getPlaca());
            ps.setInt    (6, v.getCapacidadPasajeros());
            ps.setBoolean(7, v.isOperativo());
            ResultSet rs = ps.executeQuery();
            int idVehiculo = 0;
            if (rs.next()) idVehiculo = rs.getInt(1);

            // Insertar en tabla especifica segun tipo
            if (v instanceof Bus) {
                Bus b = (Bus) v;
                PreparedStatement ps2 = con.prepareStatement(
                    "INSERT INTO buses (id_vehiculo, tipo_bus, tiene_aire_acondicionado, numero_pisos) " +
                    "VALUES (?, ?, ?, ?)");
                ps2.setInt    (1, idVehiculo);
                ps2.setString (2, b.getTipoBus());
                ps2.setBoolean(3, b.isTieneAireAcondicionado());
                ps2.setInt    (4, b.getNumeroPisos());
                ps2.executeUpdate();
            } else {
                Conbi c = (Conbi) v;
                PreparedStatement ps2 = con.prepareStatement(
                    "INSERT INTO combis (id_vehiculo, tipo_ruta, tiene_musica) " +
                    "VALUES (?, ?, ?)");
                ps2.setInt    (1, idVehiculo);
                ps2.setString (2, c.getTipoRuta());
                ps2.setBoolean(3, c.isTieneMusica());
                ps2.executeUpdate();
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error al insertar vehiculo: " + e.getMessage());
            return false;
        }
    }
    // READ
    public ArrayList<Vehiculo> listarTodos() {
        ArrayList<Vehiculo> lista = new ArrayList<>();
        String sql = "SELECT v.*, " +
                     "b.tipo_bus, b.tiene_aire_acondicionado, b.numero_pisos, " +
                     "c.tipo_ruta, c.tiene_musica " +
                     "FROM vehiculos v " +
                     "LEFT JOIN buses b ON v.id_vehiculo = b.id_vehiculo " +
                     "LEFT JOIN combis c ON v.id_vehiculo = c.id_vehiculo " +
                     "ORDER BY v.placa";
        try (Connection con = ConexionDB.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Vehiculo v = construirVehiculo(rs);
                if (v != null) lista.add(v);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar vehiculos: " + e.getMessage());
        }
        return lista;
    }

    public Vehiculo buscarPorPlaca(String placa) {
        String sql = "SELECT v.*, " +
                     "b.tipo_bus, b.tiene_aire_acondicionado, b.numero_pisos, " +
                     "c.tipo_ruta, c.tiene_musica " +
                     "FROM vehiculos v " +
                     "LEFT JOIN buses b ON v.id_vehiculo = b.id_vehiculo " +
                     "LEFT JOIN combis c ON v.id_vehiculo = c.id_vehiculo " +
                     "WHERE v.placa = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, placa.toUpperCase());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return construirVehiculo(rs);
        } catch (SQLException e) {
            System.err.println("Error al buscar vehiculo: " + e.getMessage());
        }
        return null;
    }

    private Vehiculo construirVehiculo(ResultSet rs) throws SQLException {
        String tipo = rs.getString("tipo");
        if ("Bus".equals(tipo)) {
            Bus b = new Bus();
            b.setMarca(rs.getString("marca"));
            b.setModelo(rs.getString("modelo"));
            b.setAnio(rs.getInt("anio"));
            b.setPlaca(rs.getString("placa"));
            b.setCapacidadPasajeros(rs.getInt("capacidad_pasajeros"));
            b.setOperativo(rs.getBoolean("operativo"));
            String tipoBus = rs.getString("tipo_bus");
            if (tipoBus != null) b.setTipoBus(tipoBus);
            b.setTieneAireAcondicionado(rs.getBoolean("tiene_aire_acondicionado"));
            int pisos = rs.getInt("numero_pisos");
            if (pisos > 0) b.setNumeroPisos(pisos);
            return b;
        } else {
            Conbi c = new Conbi();
            c.setMarca(rs.getString("marca"));
            c.setModelo(rs.getString("modelo"));
            c.setAnio(rs.getInt("anio"));
            c.setPlaca(rs.getString("placa"));
            c.setCapacidadPasajeros(rs.getInt("capacidad_pasajeros"));
            c.setOperativo(rs.getBoolean("operativo"));
            String tipoRuta = rs.getString("tipo_ruta");
            if (tipoRuta != null) c.setTipoRuta(tipoRuta);
            c.setTieneMusica(rs.getBoolean("tiene_musica"));
            return c;
        }
    }

    // UPDATE
    public boolean actualizarEstado(String placa, boolean operativo) {
        String sql = "UPDATE vehiculos SET operativo = ? WHERE placa = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, operativo);
            ps.setString(2, placa);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al actualizar vehiculo: " + e.getMessage());
            return false;
        }
    }

    // DELETE
    public boolean eliminar(String placa) {
        String sql = "DELETE FROM vehiculos WHERE placa = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, placa);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al eliminar vehiculo: " + e.getMessage());
            return false;
        }
    }
}
