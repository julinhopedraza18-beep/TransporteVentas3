/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

public interface UsuarioSistema {
    String getUsername();
    String getPassword();
    String getRol();
    String getNombre();
    boolean isActivo();
    boolean verificarPassword(String intento);
}
