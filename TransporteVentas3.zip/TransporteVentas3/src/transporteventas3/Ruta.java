/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;


public class Ruta {
    private String codigoRuta;
    private String origen;
    private String destino;
    private double distanciaKm;
    private int duracionMinutos;
    private double precioPasajeBase;
    private boolean activa = true;

    public String getCodigoRuta() { return codigoRuta; }
    public void setCodigoRuta(String codigoRuta) {
        if (codigoRuta == null || codigoRuta.trim().isEmpty())
            throw new IllegalArgumentException("El codigo de ruta no puede estar vacio.");
        this.codigoRuta = codigoRuta.toUpperCase().trim();
    }

    public String getOrigen() { return origen; }
    public void setOrigen(String origen) {
        if (origen == null || origen.trim().isEmpty())
            throw new IllegalArgumentException("El origen no puede estar vacio.");
        this.origen = origen.trim();
    }

    public String getDestino() { return destino; }
    public void setDestino(String destino) {
        if (destino == null || destino.trim().isEmpty())
            throw new IllegalArgumentException("El destino no puede estar vacio.");
        if (this.origen != null && this.origen.equalsIgnoreCase(destino.trim()))
            throw new IllegalArgumentException("El origen y el destino no pueden ser el mismo lugar.");
        this.destino = destino.trim();
    }

    public double getDistanciaKm() { return distanciaKm; }
    public void setDistanciaKm(double distanciaKm) {
        if (distanciaKm <= 0)
            throw new IllegalArgumentException("La distancia debe ser mayor a 0.");
        this.distanciaKm = distanciaKm;
    }

    public int getDuracionMinutos() { return duracionMinutos; }
    public void setDuracionMinutos(int duracionMinutos) {
        if (duracionMinutos <= 0)
            throw new IllegalArgumentException("La duracion debe ser mayor a 0.");
        this.duracionMinutos = duracionMinutos;
    }

    public double getPrecioPasajeBase() { return precioPasajeBase; }
    public void setPrecioPasajeBase(double precioPasajeBase) {
        if (precioPasajeBase <= 0)
            throw new IllegalArgumentException("El precio base debe ser mayor a 0.");
        this.precioPasajeBase = precioPasajeBase;
    }

    public boolean isActiva() { return activa; }
    public void setActiva(boolean activa) { this.activa = activa; }

    public String clasificarRuta() {
        if (distanciaKm <= 50)       return "Ruta Corta";
        else if (distanciaKm <= 200) return "Ruta Media";
        else                         return "Ruta Larga";
    }

    public String getDuracionFormateada() {
        int horas = duracionMinutos / 60;
        int mins  = duracionMinutos % 60;
        if (horas > 0 && mins > 0) return horas + "h " + mins + "min";
        if (horas > 0)             return horas + "h";
        return mins + "min";
    }

    public double getDuracionEnHoras() {
        return Math.round((duracionMinutos / 60.0) * 10.0) / 10.0;
    }

    public void ver_datos() {
        String estado = isActiva() ? "" : " [INACTIVA]";
        System.out.println("Ruta CODIGO: " + codigoRuta +
            " ORIGEN: " + origen + " DESTINO: " + destino +
            " DISTANCIA: " + distanciaKm + " km" +
            " DURACION: " + duracionMinutos + " min" +
            " PRECIO BASE: S/. " + String.format("%.2f", precioPasajeBase) +
            " CLASIFICACION: " + clasificarRuta() + estado);
    }
}
