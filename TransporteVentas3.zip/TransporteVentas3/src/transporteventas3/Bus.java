/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

public class Bus extends Vehiculo {
    private String tipoBus;
    private boolean tieneAireAcondicionado;
    private int numeroPisos;

    public String getTipoBus() { return tipoBus; }
    public void setTipoBus(String tipoBus) {
        if (tipoBus == null || (!tipoBus.equalsIgnoreCase("interprovincial") &&
            !tipoBus.equalsIgnoreCase("urbano") &&
            !tipoBus.equalsIgnoreCase("turistico")))
            throw new IllegalArgumentException("Tipo de bus: interprovincial / urbano / turistico.");
        this.tipoBus = tipoBus.toLowerCase();
    }

    public boolean isTieneAireAcondicionado() { return tieneAireAcondicionado; }
    public void setTieneAireAcondicionado(boolean tieneAireAcondicionado) {
        this.tieneAireAcondicionado = tieneAireAcondicionado;
    }

    public int getNumeroPisos() { return numeroPisos; }
    public void setNumeroPisos(int numeroPisos) {
        if (numeroPisos < 1 || numeroPisos > 2)
            throw new IllegalArgumentException("Numero de pisos invalido. Un bus puede tener 1 o 2 pisos.");
        this.numeroPisos = numeroPisos;
    }

    public int getCapacidadMaximaPorPisos() {
        return (numeroPisos == 2) ? 160 : 90;
    }

    @Override
    public void validarCapacidad() {
        int maxima = (numeroPisos == 2) ? 160 : 90;
        if (capacidadPasajeros > maxima)
            throw new IllegalArgumentException(
                "Un bus de " + numeroPisos + " piso(s) permite maximo " + maxima + " pasajeros.");
        if (capacidadPasajeros <= 0)
            throw new IllegalArgumentException("La capacidad debe ser mayor a 0.");
    }

    @Override
    public void ver_datos() {
        String estado = isOperativo() ? "" : " [FUERA DE SERVICIO]";
        System.out.println("Bus MARCA: " + marca + " MODELO: " + modelo +
            " ANIO: " + anio + " PLACA: " + placa +
            " CAPACIDAD: " + capacidadPasajeros + " pasajeros" +
            " CATEGORIA: " + determinarCategoria() +
            " TIPO: " + tipoBus + " PISOS: " + numeroPisos +
            " AIRE: " + (tieneAireAcondicionado ? "Si" : "No") + estado);
    }
}
