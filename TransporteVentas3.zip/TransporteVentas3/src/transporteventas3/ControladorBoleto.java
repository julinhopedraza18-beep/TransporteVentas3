/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.util.ArrayList;

public class ControladorBoleto {
    ArrayList<Boleto> boletos = new ArrayList<>();
    private BoletoDAO dao = new BoletoDAO();

    public ControladorBoleto() {
        boletos = dao.listarTodos();
    }

    public void agregar_boleto(Boleto nuevoBoleto) {
        if (nuevoBoleto == null)
            throw new IllegalArgumentException("El boleto no puede ser nulo.");

        for (int i = 0; i < boletos.size(); i++) {
            Boleto b = boletos.get(i);
            if (!b.isCancelado()
                && b.getRuta().getCodigoRuta().equalsIgnoreCase(nuevoBoleto.getRuta().getCodigoRuta())
                && b.getVehiculo().getPlaca().equalsIgnoreCase(nuevoBoleto.getVehiculo().getPlaca())
                && b.getFechaViaje().equals(nuevoBoleto.getFechaViaje())
                && b.getHoraViaje().equals(nuevoBoleto.getHoraViaje())
                && b.getAsiento().equalsIgnoreCase(nuevoBoleto.getAsiento())) {
                throw new IllegalArgumentException(
                    "El asiento " + nuevoBoleto.getAsiento() +
                    " ya esta ocupado en el vehiculo " + nuevoBoleto.getVehiculo().getPlaca() +
                    " para la fecha " + nuevoBoleto.getFechaViaje() +
                    " a las " + nuevoBoleto.getHoraViaje() + ".");
            }
        }
        dao.insertar(nuevoBoleto);
        boletos.add(nuevoBoleto);
    }

    public void listar_boletos() {
        if (boletos.isEmpty()) {
            System.out.println("No hay boletos registrados.");
            return;
        }
        for (int i = 0; i < boletos.size(); i++) {
            boletos.get(i).ver_datos();
        }
    }

    public void listar_boletos_por_ruta(String codigoRuta) {
        boolean encontrado = false;
        for (int i = 0; i < boletos.size(); i++) {
            if (boletos.get(i).getRuta().getCodigoRuta().equalsIgnoreCase(codigoRuta)) {
                boletos.get(i).ver_datos();
                encontrado = true;
            }
        }
        if (!encontrado)
            System.out.println("No hay boletos para la ruta " + codigoRuta);
    }

    public Boleto buscarPorNro(String nroBoleto) {
        for (int i = 0; i < boletos.size(); i++) {
            if (boletos.get(i).getNroBoleto().equalsIgnoreCase(nroBoleto)) {
                return boletos.get(i);
            }
        }
        return null;
    }

    public boolean cancelarBoleto(String nroBoleto) {
        Boleto b = buscarPorNro(nroBoleto);
        if (b != null && !b.isCancelado()) {
            dao.cancelar(nroBoleto);
            b.setCancelado(true);
            return true;
        }
        return false;
    }

    public void generar_reporte() {
        System.out.println("\n===== REPORTE DE VENTAS =====");
        System.out.println("Total boletos  : " + getTotalBoletos());
        System.out.println("Activos        : " + getBoletosActivos());
        System.out.println("Cancelados     : " + getBoletosCancelados());
        System.out.println("Total recaudado: S/. " + String.format("%.2f", getTotalRecaudado()));
        System.out.println("==============================");
    }

    public double getTotalRecaudado() {
        double total = 0;
        for (int i = 0; i < boletos.size(); i++) {
            if (!boletos.get(i).isCancelado())
                total += boletos.get(i).getMontoTotal();
        }
        return total;
    }

    public int getTotalBoletos(){
        return boletos.size();
    }

    public int getBoletosActivos() {
        int count = 0;
        for (int i = 0; i < boletos.size(); i++) {
            if (!boletos.get(i).isCancelado()) count++;
        }
        return count;
    }

    public int getBoletosCancelados() {
        int count = 0;
        for (int i = 0; i < boletos.size(); i++) {
            if (boletos.get(i).isCancelado()) count++;
        }
        return count;
    }
}