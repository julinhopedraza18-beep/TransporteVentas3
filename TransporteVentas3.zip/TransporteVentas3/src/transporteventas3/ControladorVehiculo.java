/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.util.ArrayList;

public class ControladorVehiculo {
    ArrayList<Vehiculo> flota = new ArrayList<>();
    private VehiculoDAO dao = new VehiculoDAO();

    public ControladorVehiculo() {
        flota = dao.listarTodos();
    }

    public void agregar_vehiculo(Vehiculo nuevoVehiculo) {
        if (nuevoVehiculo == null)
            throw new IllegalArgumentException("El vehiculo no puede ser nulo.");
        if (buscarPorPlaca(nuevoVehiculo.getPlaca()) != null)
            throw new IllegalArgumentException("Ya existe un vehiculo con la placa: " + nuevoVehiculo.getPlaca());
        dao.insertar(nuevoVehiculo);
        flota.add(nuevoVehiculo);
    }

    public void listar_vehiculos() {
        for (int i = 0; i < flota.size(); i++) {
            flota.get(i).ver_datos();
        }
    }

    public Vehiculo buscarPorPlaca(String placa) {
        for (int i = 0; i < flota.size(); i++) {
            if (flota.get(i).getPlaca().equalsIgnoreCase(placa)) {
                return flota.get(i);
            }
        }
        return null;
    }

    public boolean eliminarPorPlaca(String placa) {
        dao.eliminar(placa);
        for (int i = 0; i < flota.size(); i++) {
            if (flota.get(i).getPlaca().equalsIgnoreCase(placa)) {
                flota.remove(i);
                return true;
            }
        }
        return false;
    }

    public void actualizarEstado(String placa, boolean operativo) {
        dao.actualizarEstado(placa, operativo);
        Vehiculo v = buscarPorPlaca(placa);
        if (v != null) v.setOperativo(operativo);
    }

    public int getTotalVehiculos() { return flota.size(); }

    public int getTotalOperativos() {
        int count = 0;
        for (int i = 0; i < flota.size(); i++) {
            if (flota.get(i).isOperativo()) count++;
        }
        return count;
    }
}