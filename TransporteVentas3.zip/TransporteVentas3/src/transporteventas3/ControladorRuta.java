/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.util.ArrayList;

public class ControladorRuta {
    ArrayList<Ruta> rutas = new ArrayList<>();
    private RutaDAO dao = new RutaDAO();

    public ControladorRuta() {
        rutas = dao.listarTodas();
    }

    public void agregar_ruta(Ruta nuevaRuta) {
        if (nuevaRuta == null)
            throw new IllegalArgumentException("La ruta no puede ser nula.");
        if (buscarPorCodigo(nuevaRuta.getCodigoRuta()) != null)
            throw new IllegalArgumentException("Ya existe una ruta con codigo: " + nuevaRuta.getCodigoRuta());
        dao.insertar(nuevaRuta);
        rutas.add(nuevaRuta);
    }

    public void listar_rutas() {
        for (int i = 0; i < rutas.size(); i++) {
            rutas.get(i).ver_datos();
        }
    }

    public Ruta buscarPorCodigo(String codigo) {
        for (int i = 0; i < rutas.size(); i++) {
            if (rutas.get(i).getCodigoRuta().equalsIgnoreCase(codigo)) {
                return rutas.get(i);
            }
        }
        return null;
    }

    public boolean eliminarPorCodigo(String codigo) {
        dao.eliminar(codigo);
        for (int i = 0; i < rutas.size(); i++) {
            if (rutas.get(i).getCodigoRuta().equalsIgnoreCase(codigo)) {
                rutas.remove(i);
                return true;
            }
        }
        return false;
    }

    public void actualizarEstado(String codigo, boolean activa) {
        dao.actualizarEstado(codigo, activa);
        Ruta r = buscarPorCodigo(codigo);
        if (r != null) r.setActiva(activa);
    }

    public int getTotalRutas() { return rutas.size(); }

    public int getTotalActivas() {
        int count = 0;
        for (int i = 0; i < rutas.size(); i++) {
            if (rutas.get(i).isActiva()) count++;
        }
        return count;
    }
}