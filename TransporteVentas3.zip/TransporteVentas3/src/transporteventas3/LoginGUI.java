/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public class LoginGUI extends JFrame {

    // ── Paleta de colores ──────────────────────────────────────────────────────
    private static final Color COLOR_PRIMARIO   = new Color(26, 54, 93);
    private static final Color COLOR_ACENTO     = new Color(218, 165, 32);
    private static final Color COLOR_FONDO      = new Color(240, 244, 248);
    private static final Color COLOR_BLANCO     = Color.WHITE;
    private static final Color COLOR_ERROR      = new Color(192, 57, 43);
    private static final Color COLOR_TEXTO_GRAY = new Color(100, 116, 139);

    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JLabel lblMensaje;
    private ControladorVendedor ctrlVendedor;

    public LoginGUI(ControladorVendedor ctrlVendedor) {
        this.ctrlVendedor = ctrlVendedor;
        configurarVentana();
        construirUI();
    }

    private void configurarVentana() {
        setTitle("TransporteVentas - Inicio de Sesion");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true);
        setSize(480, 580);
        setLocationRelativeTo(null);
        setShape(new RoundRectangle2D.Double(0, 0, 480, 580, 20, 20));
        getContentPane().setBackground(COLOR_FONDO);
        setLayout(new BorderLayout());
    }

    private void construirUI() {
        // ── Panel izquierdo de color (franja decorativa superior) ─────────────
        JPanel panelHeader = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, COLOR_PRIMARIO,
                        getWidth(), getHeight(), new Color(13, 27, 62));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panelHeader.setPreferredSize(new Dimension(480, 180));
        panelHeader.setLayout(new GridBagLayout());

       // Logo + nombre empresa dentro del header
        JPanel logoPanel = new JPanel(new GridBagLayout());
        logoPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();

        // Icono de bus (texto unicode / emoji como placeholder visual)
        JLabel iconoBus = new JLabel("🚌");
        iconoBus.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        gbc.gridy = 0; gbc.insets = new Insets(0, 0, 8, 0);
        logoPanel.add(iconoBus, gbc);

        JLabel lblEmpresa = new JLabel("TRANSPORTES DEL NORTE");
        lblEmpresa.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblEmpresa.setForeground(COLOR_BLANCO);
        gbc.gridy = 1; gbc.insets = new Insets(0, 0, 4, 0);
        logoPanel.add(lblEmpresa, gbc);

        JLabel lblSistema = new JLabel("Sistema de Ventas v1.0");
        lblSistema.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSistema.setForeground(COLOR_ACENTO);
        gbc.gridy = 2; gbc.insets = new Insets(0, 0, 0, 0);
        logoPanel.add(lblSistema, gbc);

        panelHeader.add(logoPanel);

        // ── Panel central del formulario ──────────────────────────────────────
        JPanel panelForm = new JPanel();
        panelForm.setBackground(COLOR_FONDO);
        panelForm.setLayout(new BoxLayout(panelForm, BoxLayout.Y_AXIS));
        panelForm.setBorder(new EmptyBorder(30, 50, 20, 50));

        JLabel lblTitulo = new JLabel("Iniciar Sesion");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(COLOR_PRIMARIO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelForm.add(lblTitulo);
        panelForm.add(Box.createVerticalStrut(6));

        JLabel lblSub = new JLabel("Ingrese sus credenciales de acceso");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSub.setForeground(COLOR_TEXTO_GRAY);
        lblSub.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelForm.add(lblSub);
        panelForm.add(Box.createVerticalStrut(30));

        // ── Fila horizontal: campos (izquierda) + icono candado (derecha) ──────
        JPanel filaCampos = new JPanel(new BorderLayout(16, 0));
        filaCampos.setOpaque(false);
        filaCampos.setAlignmentX(Component.CENTER_ALIGNMENT);
        filaCampos.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));

        // Columna izquierda: usuario + contrasena apilados
        JPanel columnaCampos = new JPanel();
        columnaCampos.setOpaque(false);
        columnaCampos.setLayout(new BoxLayout(columnaCampos, BoxLayout.Y_AXIS));

        columnaCampos.add(crearLabel("Usuario"));
        columnaCampos.add(Box.createVerticalStrut(6));
        txtUsuario = crearTextField("Ingrese su usuario");
        columnaCampos.add(txtUsuario);
        columnaCampos.add(Box.createVerticalStrut(18));

        columnaCampos.add(crearLabel("Contrasena"));
        columnaCampos.add(Box.createVerticalStrut(6));
        txtPassword = new JPasswordField();
        estilizarCampo(txtPassword, "••••••••");
        columnaCampos.add(txtPassword);

        // Columna derecha: icono de candado dibujado con Graphics2D
        JLabel iconoSeguridad = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth(), h = getHeight();
                int cx = w / 2;
                int cy = (h - 70) / 2;
                if (cy < 0) cy = 0;

                g2.setColor(new Color(218, 165, 32, 60));
                g2.fillOval(cx - 35, cy, 70, 70);

                g2.setColor(COLOR_PRIMARIO);
                g2.setStroke(new BasicStroke(6, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawArc(cx - 14, cy + 12, 28, 30, 0, 180);

                g2.setColor(COLOR_PRIMARIO);
                g2.fillRoundRect(cx - 19, cy + 28, 38, 30, 8, 8);

                g2.setColor(Color.WHITE);
                g2.fillOval(cx - 5, cy + 36, 10, 10);
                g2.fillRect(cx - 2, cy + 43, 4, 9);

                g2.dispose();
            }
        };
        iconoSeguridad.setPreferredSize(new Dimension(90, 160));
        iconoSeguridad.setOpaque(false);

        filaCampos.add(columnaCampos, BorderLayout.CENTER);
        filaCampos.add(iconoSeguridad, BorderLayout.EAST);

        panelForm.add(filaCampos);
        panelForm.add(Box.createVerticalStrut(8));

        // Mensaje de error
        lblMensaje = new JLabel(" ");
        lblMensaje.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblMensaje.setForeground(COLOR_ERROR);
        lblMensaje.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelForm.add(lblMensaje);
        panelForm.add(Box.createVerticalStrut(18));

        // Boton ingresar
        JButton btnIngresar = crearBotonPrincipal("INGRESAR");
        btnIngresar.addActionListener(e -> intentarLogin());
        panelForm.add(btnIngresar);
        panelForm.add(Box.createVerticalStrut(16));

        // Hint de credenciales (para demo)
        JLabel lblHint = new JLabel("Demo: admin / admin123");
        lblHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblHint.setForeground(COLOR_TEXTO_GRAY);
        lblHint.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelForm.add(lblHint);

        // ── Panel inferior ────────────────────────────────────────────────────
        JPanel panelFooter = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelFooter.setBackground(COLOR_FONDO);
        JLabel lblFooter = new JLabel("© 2026 Transportes del Norte S.A.C.");
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblFooter.setForeground(COLOR_TEXTO_GRAY);
        panelFooter.add(lblFooter);

        // Boton cerrar la ventana (X en esquina)
        JButton btnCerrar = new JButton("✕");
        btnCerrar.setForeground(COLOR_BLANCO);
        btnCerrar.setBackground(new Color(0, 0, 0, 0));
        btnCerrar.setBorderPainted(false);
        btnCerrar.setFocusPainted(false);
        btnCerrar.setContentAreaFilled(false);
        btnCerrar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCerrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCerrar.addActionListener(e -> System.exit(0));
        btnCerrar.setBounds(445, 10, 28, 28);

        // Capa para posicionar el boton cerrar
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(480, 180));
        panelHeader.setBounds(0, 0, 480, 180);
        layeredPane.add(panelHeader, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(btnCerrar, JLayeredPane.PALETTE_LAYER);

        // Arrastrar ventana
        MouseAdapter drag = new MouseAdapter() {
            private Point inicio;
            public void mousePressed(MouseEvent e) { inicio = e.getPoint(); }
            public void mouseDragged(MouseEvent e) {
                Point pos = getLocation();
                setLocation(pos.x + e.getX() - inicio.x, pos.y + e.getY() - inicio.y);
            }
        };
        layeredPane.addMouseListener(drag);
        layeredPane.addMouseMotionListener(drag);

        // Enter para login
        txtPassword.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) intentarLogin();
            }
        });
        txtUsuario.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) txtPassword.requestFocus();
            }
        });

        add(layeredPane, BorderLayout.NORTH);
        add(panelForm, BorderLayout.CENTER);
        add(panelFooter, BorderLayout.SOUTH);
    }

    // ── Helpers de estilo ──────────────────────────────────────────────────────
    private JLabel crearLabel(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(new Color(51, 65, 85));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private JTextField crearTextField(String placeholder) {
        JTextField tf = new JTextField();
        estilizarCampo(tf, placeholder);
        return tf;
    }

    private void estilizarCampo(JTextField tf, String placeholder) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBackground(COLOR_BLANCO);
        tf.setForeground(new Color(30, 41, 59));
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(203, 213, 225), 1, true),
            BorderFactory.createEmptyBorder(10, 14, 10, 14)
        ));
        tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        tf.setAlignmentX(Component.LEFT_ALIGNMENT);
        tf.putClientProperty("JTextField.placeholderText", placeholder);
    }

    private JButton crearBotonPrincipal(String texto) {
        JButton btn = new JButton(texto) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, COLOR_PRIMARIO,
                        getWidth(), getHeight(), new Color(13, 27, 62));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(COLOR_BLANCO);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { btn.setForeground(COLOR_ACENTO); }
            @Override public void mouseExited(MouseEvent e)  { btn.setForeground(COLOR_BLANCO); }
        });
        return btn;
    }

    // ── Logica de autenticacion ───────────────────────────────────────────────
    private void intentarLogin() {
        String user = txtUsuario.getText().trim();
        String pass = new String(txtPassword.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            mostrarError("Complete todos los campos.");
            return;
        }

        UsuarioSistema usuarioAutenticado = ctrlVendedor.autenticar(user, pass);
        if (usuarioAutenticado != null) {
            dispose();
            SwingUtilities.invokeLater(() -> {
                MenuPrincipalGUI menu = new MenuPrincipalGUI(usuarioAutenticado);   
                menu.setVisible(true);
            });
        } else {
            mostrarError("Usuario o contrasena incorrectos.");
            txtPassword.setText("");
            txtPassword.requestFocus();
        }
    }

    private void mostrarError(String msg) {
        lblMensaje.setText(msg);
        lblMensaje.setForeground(COLOR_ERROR);
        Timer t = new Timer(3000, e -> lblMensaje.setText(" "));
        t.setRepeats(false);
        t.start();
    }
}
