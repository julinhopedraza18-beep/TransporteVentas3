/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.sql.*;

public class VendedorDAO {

    public UsuarioSistema autenticar(String username, String password) {
        String sql = "SELECT p.*, v.username, v.password, v.rol, v.activo " +
                     "FROM vendedores v INNER JOIN personas p ON v.id_persona = p.id_persona " +
                     "WHERE v.username = ? AND v.password = ? AND v.activo = 1";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username.toLowerCase().trim());
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String rol    = rs.getString("rol");
                String nom    = rs.getString("nombre");
                String pat    = rs.getString("ape_paterno");
                String tel    = rs.getString("telefono");
                String user   = rs.getString("username");
                String pass   = rs.getString("password");

                switch (rol) {
                    case "admin":
                        Administrador a = new Administrador(user, pass, nom, pat, tel);
                        a.setActivo(rs.getBoolean("activo"));
                        if (rs.getString("ape_materno") != null)
                            a.setApe_materno(rs.getString("ape_materno"));
                        return a;
                    case "supervisor":
                        Supervisor s = new Supervisor(user, pass, nom, pat, tel);
                        s.setActivo(rs.getBoolean("activo"));
                        if (rs.getString("ape_materno") != null)
                            s.setApe_materno(rs.getString("ape_materno"));
                        return s;
                    default:
                        Vendedor v = new Vendedor(user, pass, nom, pat, tel);
                        v.setActivo(rs.getBoolean("activo"));
                        if (rs.getString("ape_materno") != null)
                            v.setApe_materno(rs.getString("ape_materno"));
                        return v;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al autenticar: " + e.getMessage());
        }
        return null;
    }
}