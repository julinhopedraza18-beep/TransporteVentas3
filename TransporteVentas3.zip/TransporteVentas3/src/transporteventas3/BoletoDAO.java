/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transporteventas3;

import java.sql.*;
import java.util.ArrayList;

public class BoletoDAO {

    // CREATE
    public boolean insertar(Boleto b) {
        // Primero insertar cliente (persona + cliente)
        int idCliente = insertarCliente(b.getCliente());
        if (idCliente == -1) return false;

        String sql = "INSERT INTO boletos (nro_boleto, id_ruta, id_vehiculo, id_conductor, id_cliente, " +
                     "fecha_viaje, hora_viaje, asiento, descuento, recargo, monto_total, cancelado) " +
                     "VALUES (?, " +
                     "(SELECT id_ruta FROM rutas WHERE codigo_ruta=?), " +
                     "(SELECT id_vehiculo FROM vehiculos WHERE placa=?), " +
                     "(SELECT c.id_conductor FROM conductores c INNER JOIN personas p ON c.id_persona=p.id_persona WHERE c.nro_licencia=?), " +
                     "?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, b.getNroBoleto());
            ps.setString(2, b.getRuta().getCodigoRuta());
            ps.setString(3, b.getVehiculo().getPlaca());
            ps.setString(4, b.getConductor().getNroLicencia());
            ps.setInt   (5, idCliente);
            ps.setDate  (6, Date.valueOf(b.getFechaViaje()));
            ps.setTime  (7, Time.valueOf(b.getHoraViaje()));
            ps.setString(8, b.getAsiento());
            ps.setDouble(9, b.getDescuento());
            ps.setDouble(10, b.getRecargo());
            ps.setDouble(11, b.getMontoTotal());
            ps.setBoolean(12, b.isCancelado());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al insertar boleto: " + e.getMessage());
            return false;
        }
    }

    private int insertarCliente(Cliente c) {
        String sqlP = "INSERT INTO personas (tipo_documento, nro_documento, nombre, ape_paterno, ape_materno, telefono) " +
                      "VALUES (?, ?, ?, ?, ?, ?); SELECT SCOPE_IDENTITY();";
        String sqlC = "INSERT INTO clientes (id_persona, tipo_cliente) VALUES (?, ?); SELECT SCOPE_IDENTITY();";
        try (Connection con = ConexionDB.getConexion()) {
            PreparedStatement ps1 = con.prepareStatement(sqlP);
            ps1.setString(1, c.getTipoDocumento());
            ps1.setString(2, c.getNroDocumento());
            ps1.setString(3, c.getNombre());
            ps1.setString(4, c.getApe_paterno());
            ps1.setString(5, c.getApe_materno());
            ps1.setString(6, c.getTelefono());
            ResultSet rs1 = ps1.executeQuery();
            int idPersona = 0;
            if (rs1.next()) idPersona = rs1.getInt(1);

            PreparedStatement ps2 = con.prepareStatement(sqlC);
            ps2.setInt   (1, idPersona);
            ps2.setString(2, c.getTipoCliente());
            ResultSet rs2 = ps2.executeQuery();
            if (rs2.next()) return rs2.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error al insertar cliente: " + e.getMessage());
        }
        return -1;
    }

    // READ
    public ArrayList<Boleto> listarTodos() {
        ArrayList<Boleto> lista = new ArrayList<>();
        String sql = "SELECT b.*, " +
                     "r.codigo_ruta, r.origen, r.destino, r.distancia_km, r.duracion_minutos, r.precio_base, r.activa, " +
                     "v.placa, v.tipo, v.marca, v.modelo, v.anio, v.capacidad_pasajeros, v.operativo, " +
                     "bus.tipo_bus, bus.tiene_aire_acondicionado, bus.numero_pisos, " +
                     "c.tipo_ruta, c.tiene_musica, " +
                     "p_con.tipo_documento as con_tdoc, p_con.nro_documento as con_ndoc, " +
                     "p_con.nombre as con_nom, p_con.ape_paterno as con_pat, p_con.ape_materno as con_mat, " +
                     "p_con.telefono as con_tel, con.nro_licencia, con.categoria_licencia, con.disponible, " +
                     "p_cli.tipo_documento as cli_tdoc, p_cli.nro_documento as cli_ndoc, " +
                     "p_cli.nombre as cli_nom, p_cli.ape_paterno as cli_pat, p_cli.ape_materno as cli_mat, " +
                     "p_cli.telefono as cli_tel, cli.tipo_cliente " +
                     "FROM boletos b " +
                     "INNER JOIN rutas r ON b.id_ruta = r.id_ruta " +
                     "INNER JOIN vehiculos v ON b.id_vehiculo = v.id_vehiculo " +
                     "LEFT JOIN buses bus ON v.id_vehiculo = bus.id_vehiculo " +
                     "LEFT JOIN combis c ON v.id_vehiculo = c.id_vehiculo " +
                     "INNER JOIN conductores con ON b.id_conductor = con.id_conductor " +
                     "INNER JOIN personas p_con ON con.id_persona = p_con.id_persona " +
                     "INNER JOIN clientes cli ON b.id_cliente = cli.id_cliente " +
                     "INNER JOIN personas p_cli ON cli.id_persona = p_cli.id_persona " +
                     "ORDER BY b.nro_boleto";
        try (Connection con = ConexionDB.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(construirBoleto(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al listar boletos: " + e.getMessage());
        }
        return lista;
    }

    private Boleto construirBoleto(ResultSet rs) throws SQLException {
        Ruta ruta = new Ruta();
        ruta.setCodigoRuta(rs.getString("codigo_ruta"));
        ruta.setOrigen(rs.getString("origen"));
        ruta.setDestino(rs.getString("destino"));
        ruta.setDistanciaKm(rs.getDouble("distancia_km"));
        ruta.setDuracionMinutos(rs.getInt("duracion_minutos"));
        ruta.setPrecioPasajeBase(rs.getDouble("precio_base"));
        ruta.setActiva(rs.getBoolean("activa"));

        Vehiculo vehiculo;
        if ("Bus".equals(rs.getString("tipo"))) {
            Bus b = new Bus();
            String tipoBus = rs.getString("tipo_bus");
            if (tipoBus != null) b.setTipoBus(tipoBus);
            b.setTieneAireAcondicionado(rs.getBoolean("tiene_aire_acondicionado"));
            int pisos = rs.getInt("numero_pisos");
            if (pisos > 0) b.setNumeroPisos(pisos);
            vehiculo = b;
        } else {
            Conbi c = new Conbi();
            String tipoRuta = rs.getString("tipo_ruta");
            if (tipoRuta != null) c.setTipoRuta(tipoRuta);
            c.setTieneMusica(rs.getBoolean("tiene_musica"));
            vehiculo = c;
        }
        vehiculo.setMarca(rs.getString("marca"));
        vehiculo.setModelo(rs.getString("modelo"));
        vehiculo.setAnio(rs.getInt("anio"));
        vehiculo.setPlaca(rs.getString("placa"));
        vehiculo.setCapacidadPasajeros(rs.getInt("capacidad_pasajeros"));
        vehiculo.setOperativo(rs.getBoolean("operativo"));

        Conductor conductor = new Conductor();
        conductor.setTipoDocumento(rs.getString("con_tdoc"));
        conductor.setNroDocumento(rs.getString("con_ndoc"));
        conductor.setNombre(rs.getString("con_nom"));
        conductor.setApe_paterno(rs.getString("con_pat"));
        conductor.setApe_materno(rs.getString("con_mat"));
        conductor.setTelefono(rs.getString("con_tel"));
        conductor.setNroLicencia(rs.getString("nro_licencia"));
        conductor.setCategoriaLicencia(rs.getString("categoria_licencia"));
        conductor.setDisponible(rs.getBoolean("disponible"));

        Cliente cliente = new Cliente();
        cliente.setTipoDocumento(rs.getString("cli_tdoc"));
        cliente.setNroDocumento(rs.getString("cli_ndoc"));
        cliente.setNombre(rs.getString("cli_nom"));
        cliente.setApe_paterno(rs.getString("cli_pat"));
        cliente.setApe_materno(rs.getString("cli_mat"));
        cliente.setTelefono(rs.getString("cli_tel"));
        cliente.setTipoCliente(rs.getString("tipo_cliente"));

        Boleto boleto = new Boleto();
        boleto.setNroBoleto(rs.getString("nro_boleto"));
        boleto.setRuta(ruta);
        boleto.setVehiculo(vehiculo);
        boleto.setConductor(conductor);
        boleto.setCliente(cliente);
        boleto.setFechaViaje(rs.getDate("fecha_viaje").toLocalDate());
        boleto.setHoraViaje(rs.getTime("hora_viaje").toLocalTime());
        boleto.setAsiento(rs.getString("asiento"));
        boleto.setDescuento(rs.getDouble("descuento"));
        boleto.setRecargo(rs.getDouble("recargo"));
        boleto.setCancelado(rs.getBoolean("cancelado"));
        boleto.calcularTotal();
        return boleto;
    }

    // UPDATE - cancelar boleto
    public boolean cancelar(String nroBoleto) {
        String sql = "UPDATE boletos SET cancelado = 1 WHERE nro_boleto = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nroBoleto);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al cancelar boleto: " + e.getMessage());
            return false;
        }
    }

    public int contarBoletos() {
        String sql = "SELECT COUNT(*) FROM boletos";
        try (Connection con = ConexionDB.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error al contar boletos: " + e.getMessage());
        }
        return 0;
    }
}
